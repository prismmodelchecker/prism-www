---
layout: layouts/base.njk
title: "AIMS-QuantVer'18 - PRISM Lab Session"
section: doc
permalink: /courses/aims1718/lab/
---
# [AIMS-QuantVer'18](/courses/aims1718/): Quantitative verification, part of the Systems Verification course of the AIMS CDT

## PRISM Lab Session

This hands-on tool session will introduce you to [PRISM](/). To get started, [download](/download/) and [install](/manual/InstallingPRISM/Instructions) it. It is best to make sure that you are running the latest version (currently 4.4), but any version from 4.1 onwards should be fine.

This lab session is self-contained, but if you want information about running PRISM the best source is the online [manual](/manual/).

There are three parts, of which Parts A and B are of standard difficulty, and Part C is considered advanced:

-   [Part A](/courses/aims1718/die/) uses a simple discrete-time Markov chain (DTMC) example - a randomised algorithm for modelling a **6-sided die** with a **fair coin**. It introduces the basics of the PRISM modelling language and the PRISM tool.  
      
    
-   [Part B](/courses/aims1718/deliveryRobot/) is an example of a **mail delivering robot** and illustrates how to build PRISM models comprising several interacting components. It uses both DTMCs and Markov decision processes (MDPs).  
      
    
-   [Part C](/courses/aims1718/power/) is based on a **dynamic power management** system, and illustrates how to build PRISM models comprising multiple interacting components. It uses both DTMCs and MDPs.

If you want to learn about other aspects of PRISM, take a look at the main online [tutorial](/tutorial/).

You can also find many more interesting examples in the [case studies](/casestudies/) section of the website.
