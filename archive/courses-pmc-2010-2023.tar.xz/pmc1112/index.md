---
layout: layouts/base.njk
title: "Probabilistic Model Checking - Practicals"
section: doc
permalink: /courses/pmc1112/
---
# [Probabilistic Model Checking Practicals](/courses/pmc1112/)

## Michaelmas Term 2011

* * *

These practical exercises are based on the [PRISM](/) tool. This is already installed (under Linux) on the lab machines in room 379. However, you will be expected to complete some of this work outside of the lab sessions. You will also require PRISM to complete the take-home assignment at the end of the course. Therefore, you will mostly likely wish to install a copy of PRISM on your own machine. Please see either [Dave Parker](http://www.cs.ox.ac.uk/people/David.Parker/) or [Aistis Simaitis](http://www.cs.ox.ac.uk/people/Aistis.Simaitis/) as soon as possible if you have any problems in this respect.

**Running PRISM in room 379:**  
PRISM is installed under Linux on these machines. You can run it by just typing `xprism` at the command line.

**Installing PRISM on your own machine:**  
See [here](/courses/pmc1112/prism/).

* * *

## Resources

The best source of information about PRISM is the online [manual](/manual/).

Outside of the lab sessions, general questions about PRISM (but not specifically about the exercises, please) can be sent to the [PRISM discussion group](http://groups.google.com/group/prismmodelchecker).

* * *

## The Practicals

Links to each of the 4 practical exercises will appear here:

-   [Practical 1](/courses/pmc1112/practical1/)
-   [Practical 2](/courses/pmc1112/practical2/)
-   [Practical 3](/courses/pmc1112/practical3/)
-   [Practical 4](/courses/pmc1112/practical4/)

* * *
