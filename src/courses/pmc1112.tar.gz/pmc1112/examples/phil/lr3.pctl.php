<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>
lr3.pctl
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- Style sheet "prism.css" can be found in the "etc" directory of the PRISM distribution -->
<link type="text/css" rel="stylesheet" href="/casestudies/examples/prism.css">
</head>
<body text="#000000" bgcolor="#ffffff">
<pre>
<span class="prismcomment">// deadlock freeness</span>
<span class="prismkeyword">filter</span>(<span class="prismident">forall</span>, "<span class="prismident">hungry</span>" =&gt; <span class="prismkeyword">P</span>&gt;=<span class="prismnum">1</span> [ <span class="prismkeyword">F</span> "<span class="prismident">eat</span>"])

<span class="prismcomment">// no resource starvation</span>
<span class="prismkeyword">filter</span>(<span class="prismident">forall</span>, "<span class="prismident">hungry1</span>" =&gt; <span class="prismkeyword">P</span>&gt;=<span class="prismnum">1</span> [ <span class="prismkeyword">F</span> "<span class="prismident">eat1</span>"])
<span class="prismkeyword">filter</span>(<span class="prismident">forall</span>, "<span class="prismident">hungry2</span>" =&gt; <span class="prismkeyword">P</span>&gt;=<span class="prismnum">1</span> [ <span class="prismkeyword">F</span> "<span class="prismident">eat2</span>"])
<span class="prismkeyword">filter</span>(<span class="prismident">forall</span>, "<span class="prismident">hungry3</span>" =&gt; <span class="prismkeyword">P</span>&gt;=<span class="prismnum">1</span> [ <span class="prismkeyword">F</span> "<span class="prismident">eat3</span>"])
</pre>
</body>
</html>
