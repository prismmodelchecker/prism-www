<span class="prismkeyword">const</span> <span class="prismkeyword">int</span> <span class="prismident">T</span>;

<span class="prismcomment">// What is the probability of the queue being full at time T?</span>
<span class="prismkeyword">P</span>=? [ <span class="prismkeyword">F</span>[<span class="prismident">T</span>,<span class="prismident">T</span>] <span class="prismident">q</span>=<span class="prismident">q_max</span> ]

<span class="prismcomment">// What is the long-run probability of the queue being full?</span>
<span class="prismkeyword">S</span>=? [ <span class="prismident">q</span>=<span class="prismident">q_max</span> ]

<span class="prismcomment">// What is the expected size of the queue at time T?</span>
<span class="prismkeyword">R</span>=? [ <span class="prismkeyword">I</span>=<span class="prismident">T</span> ]

<span class="prismcomment">// What is the long-run expected size of the queue?</span>
<span class="prismkeyword">R</span>=? [ <span class="prismkeyword">S</span> ]
