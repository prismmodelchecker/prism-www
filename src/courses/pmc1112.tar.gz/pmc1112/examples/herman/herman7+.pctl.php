<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>
herman7+.pctl
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- Style sheet "prism.css" can be found in the "etc" directory of the PRISM distribution -->
<link type="text/css" rel="stylesheet" href="/casestudies/examples/prism.css">
</head>
<body text="#000000" bgcolor="#ffffff">
<pre>
<span class="prismcomment">// stable states - where only one process has the same value as the process to its left</span>
<span class="prismkeyword">label</span> "<span class="prismident">stable</span>" = <span class="prismident">num_tokens</span>=<span class="prismnum">1</span>;

<span class="prismcomment">// from the initial state, a stable state is reached with probability 1</span>
<span class="prismkeyword">P</span>&gt;=<span class="prismnum">1</span> [ <span class="prismkeyword">F</span> "<span class="prismident">stable</span>" ]

<span class="prismcomment">// from the initial state, what is the probability of</span>
<span class="prismcomment">// reaching a stable state within 10 steps</span>
<span class="prismkeyword">P</span>=? [ <span class="prismkeyword">F</span>&lt;=<span class="prismnum">10</span> "<span class="prismident">stable</span>" ]

<span class="prismcomment">// what is the expected number of steps required to reach a stable state?</span>
<span class="prismkeyword">R</span>=? [ <span class="prismkeyword">F</span> "<span class="prismident">stable</span>" ]
</pre>
</body>
</html>
