<span class="prismcomment">// stable states - where only one process has the same value as the process to its left</span>
<span class="prismkeyword">label</span> "<span class="prismident">stable</span>" = <span class="prismident">num_tokens</span>=<span class="prismnum">1</span>;

<span class="prismcomment">// from the initial state, a stable state is reached with probability 1</span>
<span class="prismkeyword">P</span>&gt;=<span class="prismnum">1</span> [ <span class="prismkeyword">F</span> "<span class="prismident">stable</span>" ]
