<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>
die+.pm
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- Style sheet "prism.css" can be found in the "etc" directory of the PRISM distribution -->
<link type="text/css" rel="stylesheet" href="/casestudies/examples/prism.css">
</head>
<body text="#000000" bgcolor="#ffffff">
<pre>
<span class="prismkeyword">dtmc</span>

<span class="prismkeyword">module</span> <span class="prismident">die</span>

	<span class="prismcomment">// local state</span>
	<span class="prismident">s</span> : [<span class="prismnum">0</span>..<span class="prismnum">7</span>] <span class="prismkeyword">init</span> <span class="prismnum">0</span>;
	<span class="prismcomment">// value of the die</span>
	<span class="prismident">d</span> : [<span class="prismnum">0</span>..<span class="prismnum">6</span>] <span class="prismkeyword">init</span> <span class="prismnum">0</span>;
	
	[] <span class="prismident">s</span>=<span class="prismnum">0</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">1</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">2</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">1</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">3</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">4</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">2</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">5</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">6</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">3</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">1</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">7</span>) &amp; (<span class="prismident">d'</span>=<span class="prismnum">1</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">4</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">7</span>) &amp; (<span class="prismident">d'</span>=<span class="prismnum">2</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">7</span>) &amp; (<span class="prismident">d'</span>=<span class="prismnum">3</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">5</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">7</span>) &amp; (<span class="prismident">d'</span>=<span class="prismnum">4</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">7</span>) &amp; (<span class="prismident">d'</span>=<span class="prismnum">5</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">6</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">2</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">7</span>) &amp; (<span class="prismident">d'</span>=<span class="prismnum">6</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">7</span> -&gt; (<span class="prismident">s'</span>=<span class="prismnum">7</span>);
	
<span class="prismkeyword">endmodule</span>

<span class="prismkeyword">rewards</span> "<span class="prismident">steps</span>"
	<span class="prismkeyword">true</span> : <span class="prismnum">1</span>;
<span class="prismkeyword">endrewards</span>
</pre>
</body>
</html>
