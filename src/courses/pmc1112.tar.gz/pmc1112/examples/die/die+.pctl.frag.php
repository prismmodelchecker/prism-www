<span class="prismkeyword">const</span> <span class="prismkeyword">int</span> <span class="prismident">x</span>;

<span class="prismkeyword">P</span>=? [ <span class="prismkeyword">F</span> <span class="prismident">s</span>=<span class="prismnum">7</span> &amp; <span class="prismident">d</span>=<span class="prismident">x</span> ]

<span class="prismkeyword">R</span>=? [ <span class="prismkeyword">F</span> <span class="prismident">s</span>=<span class="prismnum">7</span> ]
