<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>
egl4.pm
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- Style sheet "prism.css" can be found in the "etc" directory of the PRISM distribution -->
<link type="text/css" rel="stylesheet" href="/casestudies/examples/prism.css">
</head>
<body text="#000000" bgcolor="#ffffff">
<pre>
<span class="prismcomment">// Randomised protocol for signing contracts taken from:</span>
<span class="prismcomment">// S. Even, O. Goldreich, and A. Lempel.</span>
<span class="prismcomment">// A randomized protocol for signing contracts.</span>
<span class="prismcomment">// Communications of the ACM, 28(6):637 647, 1985.</span>

<span class="prismcomment">//-----------------------------------------------------------------------------------------</span>

<span class="prismkeyword">dtmc</span> <span class="prismcomment">// Model is a DTMC (no nondeterminism)</span>

<span class="prismcomment">// CONSTANTS:</span>

<span class="prismcomment">// N: number of pairs of secrets each party sends</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">int</span> <span class="prismident">N</span>;
<span class="prismcomment">// L: number of bits in each secret (fix at 2)</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">int</span> <span class="prismident">L</span>=<span class="prismnum">2</span>;

<span class="prismcomment">// FORMULAE:</span>

<span class="prismcomment">// B knows a pair of secrets</span>
<span class="prismkeyword">formula</span> <span class="prismident">kB</span> = ( (<span class="prismident">a1_0</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_0</span>=<span class="prismident">L</span>)
             | (<span class="prismident">a1_1</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_1</span>=<span class="prismident">L</span>)
             | (<span class="prismident">a1_2</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_2</span>=<span class="prismident">L</span>)
             | (<span class="prismident">a1_3</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_3</span>=<span class="prismident">L</span>)
             | (<span class="prismident">a1_4</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_4</span>=<span class="prismident">L</span>)
             | (<span class="prismident">a1_5</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_5</span>=<span class="prismident">L</span>)
             | (<span class="prismident">a1_6</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_6</span>=<span class="prismident">L</span>)
             | (<span class="prismident">a1_7</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_7</span>=<span class="prismident">L</span>)
             | (<span class="prismident">a1_8</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_8</span>=<span class="prismident">L</span>)
             | (<span class="prismident">a1_9</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_9</span>=<span class="prismident">L</span>));
<span class="prismcomment">// A knows a pair of secrets</span>
<span class="prismkeyword">formula</span> <span class="prismident">kA</span> = ( (<span class="prismident">b1_0</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_0</span>=<span class="prismident">L</span>)
             | (<span class="prismident">b1_1</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_1</span>=<span class="prismident">L</span>)
             | (<span class="prismident">b1_2</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_2</span>=<span class="prismident">L</span>)
             | (<span class="prismident">b1_3</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_3</span>=<span class="prismident">L</span>)
             | (<span class="prismident">b1_4</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_4</span>=<span class="prismident">L</span>)
             | (<span class="prismident">b1_5</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_5</span>=<span class="prismident">L</span>)
             | (<span class="prismident">b1_6</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_6</span>=<span class="prismident">L</span>)
             | (<span class="prismident">b1_7</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_7</span>=<span class="prismident">L</span>)
             | (<span class="prismident">b1_8</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_8</span>=<span class="prismident">L</span>)
             | (<span class="prismident">b1_9</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_9</span>=<span class="prismident">L</span>));

<span class="prismcomment">//-----------------------------------------------------------------------------------------</span>

<span class="prismcomment">// Scheduler: used to order the sending of messages between parties A and B</span>

<span class="prismkeyword">module</span> <span class="prismident">scheduler</span>
	
	<span class="prismcomment">// b: which bit of the secret a party should send next</span>
	<span class="prismident">b</span> : [<span class="prismnum">1</span>..<span class="prismident">L</span>];
	<span class="prismcomment">// n: which secret a party should send next</span>
	<span class="prismident">n</span> : [<span class="prismnum">0</span>..<span class="prismkeyword">max</span>(<span class="prismident">N</span>-<span class="prismnum">1</span>,<span class="prismnum">1</span>)];
	<span class="prismcomment">// phase: current phase of the protocol</span>
	<span class="prismcomment">//        1   = sending messages of the form OT(.,.,.,.)</span>
	<span class="prismcomment">//        2&amp;3 = sending secrets 1..N and N+1..2N, respectively</span>
	<span class="prismcomment">//        4   = finished</span>
	<span class="prismident">phase</span> : [<span class="prismnum">1</span>..<span class="prismnum">5</span>];
	<span class="prismcomment">// party: which party moves next</span>
	<span class="prismident">party</span> : [<span class="prismnum">1</span>..<span class="prismnum">2</span>];
	
	<span class="prismcomment">// FIRST PHASE:</span>
	
	<span class="prismcomment">// A sends a message, B will go next</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> -&gt; (<span class="prismident">party'</span>=<span class="prismnum">2</span>);
	<span class="prismcomment">// B sends a message, move onto next message and go back to A</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">party'</span>=<span class="prismnum">1</span>) &amp; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>);
	<span class="prismcomment">// B sends final (Nth) message, move to next phase</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">party'</span>=<span class="prismnum">1</span>) &amp; (<span class="prismident">phase'</span>=<span class="prismnum">2</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>); 
	
	<span class="prismcomment">// SECOND AND THIRD PHASES (interleaved for A and B):</span>
	
	<span class="prismcomment">// when A sends</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span>..<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">0</span> -&gt; (<span class="prismident">party'</span>=<span class="prismnum">2</span>); <span class="prismcomment">// A transmits bth bit of secrets 1..N or N=1..2N</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span>..<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">N</span>&gt;<span class="prismnum">1</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>); <span class="prismcomment">// A transmits bth bit of secrets 1..N or N=1..2N</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span>..<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; (<span class="prismident">N</span>=<span class="prismnum">1</span> | <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span>) -&gt; (<span class="prismident">party'</span>=<span class="prismnum">1</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">1</span>); <span class="prismcomment">// finished for party A now move to party B</span>
	<span class="prismcomment">// when A sends</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span>..<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> &amp; <span class="prismident">N</span>&gt;<span class="prismnum">0</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span> &amp; <span class="prismident">n</span>&gt;<span class="prismnum">0</span> -&gt; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>); <span class="prismcomment">// B transmits bth bit of secrets 1..N or N=1..2N</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span>..<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> &amp; (<span class="prismident">N</span>=<span class="prismnum">1</span> | <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span>) &amp; <span class="prismident">b</span>&lt;<span class="prismident">L</span> -&gt; (<span class="prismident">party'</span>=<span class="prismnum">1</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>) &amp; (<span class="prismident">b'</span>=<span class="prismident">b</span>+<span class="prismnum">1</span>); <span class="prismcomment">// finished for party B move to next bit</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> &amp; (<span class="prismident">N</span>=<span class="prismnum">1</span> | <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span>) &amp; <span class="prismident">b</span>=<span class="prismident">L</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">3</span>) &amp; (<span class="prismident">party'</span>=<span class="prismnum">1</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>) &amp; (<span class="prismident">b'</span>=<span class="prismnum">1</span>); <span class="prismcomment">// finished for party B move to next phase</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> &amp; (<span class="prismident">N</span>=<span class="prismnum">1</span> | <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span>) &amp; <span class="prismident">b</span>=<span class="prismident">L</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">4</span>); <span class="prismcomment">// finished protocol (reveal values)</span>
	
<span class="prismcomment">// 	// A sends bth bit of nth secret (for  n=1..N-1), move to next secret</span>
<span class="prismcomment">// 	[receiveB] phase=2 &amp; party=1 &amp; n&lt;N-1-&gt; (n'=n+1);</span>
<span class="prismcomment">// 	// A sends bth bit of Nth secret, B will go next</span>
<span class="prismcomment">// 	[receiveB] phase=2 &amp; party=1 &amp; n=N-1 -&gt; (phase'=2) &amp; (party'=2) &amp; (n'=0);</span>
<span class="prismcomment">// 	// B sends bth bit of nth secret (for  n=1..N-1), move to next secret</span>
<span class="prismcomment">// 	[receiveA] phase=2 &amp; party=2 &amp; n&lt;N-1 -&gt; (n'=n+1);</span>
<span class="prismcomment">// 	// B sends bth bit of Nth secret, move to next phase (N+1..2N) and back to A</span>
<span class="prismcomment">// 	[receiveA] phase=2 &amp; party=2 &amp; n=N-1 -&gt; (phase'=3) &amp; (party'=1) &amp; (n'=0);</span>
<span class="prismcomment">// 	// A sends bth bit of (N+n)th secret (for  n=1..N-1), move to next secret</span>
<span class="prismcomment">// 	[receiveB] phase=3 &amp; party=1 &amp; n&lt;N-1-&gt; (n'=n+1);</span>
<span class="prismcomment">// 	// A sends bth bit of last (2Nth) secret, B will go next</span>
<span class="prismcomment">// 	[receiveB] phase=3 &amp; party=1 &amp; n=N-1 -&gt; (phase'=3) &amp; (party'=2) &amp; (n'=0);</span>
<span class="prismcomment">// 	// B sends bth bit of (N+n)th secret (for  n=1..N-1), move to next secret</span>
<span class="prismcomment">// 	[receiveA] phase=3 &amp; party=2 &amp; n&lt;N-1 -&gt; (n'=n+1);</span>
<span class="prismcomment">// 	// B sends bth bit of last (2Nth) secret, increment b and go back to A</span>
<span class="prismcomment">// 	[receiveA] phase=3 &amp; party=2 &amp; n=N-1 &amp; b&lt;L -&gt; (phase'=2) &amp; (party'=1) &amp; (n'=0) &amp; (b'=b+1);</span>
<span class="prismcomment">// 	// B sends final (Lth) bit of last (2Nth) secret, protocol is now finished</span>
<span class="prismcomment">// 	[receiveA] phase=3 &amp; party=2 &amp; n=N-1 &amp; b=L -&gt; (phase'=4);</span>
	
	<span class="prismcomment">// FINISHED (loop)</span>
	[] <span class="prismident">phase</span>=<span class="prismnum">4</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">4</span>);
	
<span class="prismkeyword">endmodule</span>

<span class="prismcomment">//-----------------------------------------------------------------------------------------</span>

<span class="prismcomment">// Party A</span>

<span class="prismkeyword">module</span> <span class="prismident">partyA</span>
	
	<span class="prismcomment">// How many bits of each of B's secrets A currently knows</span>
	<span class="prismcomment">// Secrets are in pairs and thus divided into two sets.</span>
	<span class="prismcomment">// b1_i stores the value (number of bits known) for the ith secret</span>
	<span class="prismcomment">// of the first set of secrets. b2_i stores the value</span>
	<span class="prismcomment">// for the ith secret of the second set of secrets.</span>
	<span class="prismcomment">// (Technical note: Keep pairs of secrets together</span>
	<span class="prismcomment">//  to give a more structured model and hence smaller MTBDD)</span>
	<span class="prismident">b1_0</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_0</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_1</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_1</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_2</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_2</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_3</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_3</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_4</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_4</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_5</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_5</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_6</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_6</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_7</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_7</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_8</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_8</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_9</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_9</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	
	<span class="prismcomment">// A receives either secret n-1 or N+(n-1) with equal probability</span>
	<span class="prismcomment">// (using Oblivious Transfer (OT) protocol)</span>
	<span class="prismcomment">// Note: get full secret here, i.e. all L bits</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">0</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_0'</span>=<span class="prismident">L</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">b2_0'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">1</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_1'</span>=<span class="prismident">L</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">b2_1'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">2</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_2'</span>=<span class="prismident">L</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">b2_2'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">3</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_3'</span>=<span class="prismident">L</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">b2_3'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">4</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_4'</span>=<span class="prismident">L</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">b2_4'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">5</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_5'</span>=<span class="prismident">L</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">b2_5'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">6</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_6'</span>=<span class="prismident">L</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">b2_6'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">7</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_7'</span>=<span class="prismident">L</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">b2_7'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">8</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_8'</span>=<span class="prismident">L</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">b2_8'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">9</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_9'</span>=<span class="prismident">L</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">b2_9'</span>=<span class="prismident">L</span>);
	<span class="prismcomment">// A receives single bit for secrets 0..N-1 (when scheduler module in phase 2)</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">0</span>  -&gt; (<span class="prismident">b1_0'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_0</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">1</span>  -&gt; (<span class="prismident">b1_1'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_1</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">2</span>  -&gt; (<span class="prismident">b1_2'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_2</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">3</span>  -&gt; (<span class="prismident">b1_3'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_3</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">4</span>  -&gt; (<span class="prismident">b1_4'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_4</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">5</span>  -&gt; (<span class="prismident">b1_5'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_5</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">6</span>  -&gt; (<span class="prismident">b1_6'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_6</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">7</span>  -&gt; (<span class="prismident">b1_7'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_7</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">8</span>  -&gt; (<span class="prismident">b1_8'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_8</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">9</span>  -&gt; (<span class="prismident">b1_9'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_9</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	<span class="prismcomment">// A receives single bits for secrets N..2N-1 (when scheduler module in phase 3)</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">0</span>  -&gt; (<span class="prismident">b2_0'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_0</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">1</span>  -&gt; (<span class="prismident">b2_1'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_1</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">2</span>  -&gt; (<span class="prismident">b2_2'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_2</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">3</span>  -&gt; (<span class="prismident">b2_3'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_3</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">4</span>  -&gt; (<span class="prismident">b2_4'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_4</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">5</span>  -&gt; (<span class="prismident">b2_5'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_5</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">6</span>  -&gt; (<span class="prismident">b2_6'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_6</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">7</span>  -&gt; (<span class="prismident">b2_7'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_7</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">8</span>  -&gt; (<span class="prismident">b2_8'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_8</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">9</span>  -&gt; (<span class="prismident">b2_9'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_9</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));

<span class="prismkeyword">endmodule</span>

<span class="prismcomment">//-----------------------------------------------------------------------------------------</span>

<span class="prismcomment">// Construct module for party B through renaming</span>

<span class="prismkeyword">module</span> <span class="prismident">partyB</span>=<span class="prismident">partyA</span>[<span class="prismident">b1_0</span>=<span class="prismident">a1_0</span> ,<span class="prismident">b1_1</span>=<span class="prismident">a1_1</span> ,<span class="prismident">b1_2</span>=<span class="prismident">a1_2</span> ,<span class="prismident">b1_3</span>=<span class="prismident">a1_3</span> ,<span class="prismident">b1_4</span>=<span class="prismident">a1_4</span> ,<span class="prismident">b1_5</span>=<span class="prismident">a1_5</span> ,<span class="prismident">b1_6</span>=<span class="prismident">a1_6</span> ,<span class="prismident">b1_7</span>=<span class="prismident">a1_7</span> ,<span class="prismident">b1_8</span>=<span class="prismident">a1_8</span> ,<span class="prismident">b1_9</span>=<span class="prismident">a1_9</span>,
                     <span class="prismident">b2_0</span>=<span class="prismident">a2_0</span> ,<span class="prismident">b2_1</span>=<span class="prismident">a2_1</span> ,<span class="prismident">b2_2</span>=<span class="prismident">a2_2</span> ,<span class="prismident">b2_3</span>=<span class="prismident">a2_3</span> ,<span class="prismident">b2_4</span>=<span class="prismident">a2_4</span> ,<span class="prismident">b2_5</span>=<span class="prismident">a2_5</span> ,<span class="prismident">b2_6</span>=<span class="prismident">a2_6</span> ,<span class="prismident">b2_7</span>=<span class="prismident">a2_7</span> ,<span class="prismident">b2_8</span>=<span class="prismident">a2_8</span> ,<span class="prismident">b2_9</span>=<span class="prismident">a2_9</span>,
                     <span class="prismident">receiveA</span>=<span class="prismident">receiveB</span>] 
<span class="prismkeyword">endmodule</span>
</pre>
</body>
</html>
