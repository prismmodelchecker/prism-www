<?php $title = "Probabilistic Model Checking - Practicals - Practical 2"; $nav = "doc"; require '../../includes/header.php'; ?>

<!-- ============================================================================ -->

<h1><a href="index.php">Probabilistic Model Checking Practicals</a></h1>

<h3>Practical 2</h3>

<p>
This practical concerns using the PRISM tool for the specification and analysis of discrete time Markov chain models. 
</p>

<p>
Items that should be included in your practical report are
marked with a <b>[*]</b> below
(and also summarised at the end of this page).
</p>

<!-- ============================================================================ -->

<div class="prism-rule"></div>

<h3>1. The EGL contract signing protocol</h3>

<p>
In this second practical we are going to look at a more complex PRISM case study:
a model of the EGL contract signing protocol of Even, Goldreich &amp; Lempel.
The PRISM code is shown below.
</p>

<?php prism_code("egl/egl.pm") ?>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
The first step is to understand the algorithm
and then work out how the algorithm is represented by the PRISM model shown above.
The algorithm has already been discussed in the lectures
(see the <a href="http://web.comlab.ox.ac.uk/teaching/materials08-09/probabilistic/07-costs%20rewards.pdf">slides</a>
or <a href="http://web.comlab.ox.ac.uk/teaching/materials08-09/probabilistic/07-costs%20rewards-handout.pdf">handout</a>
from lecture 7 for details) and the following notes should help to understand the PRISM model.
</p>

<ul>
<li>
The PRISM model comprises three modules.
Two of these represent the (symmetric) parties, <em>A</em> and <em>B</em>, which take part in the contract signing.
The third represents a scheduler which controls the order in which <em>A</em> and <em>B</em> send messages to each other,
and thus captures the details of the algorithm itself.

<li><p>
Let's look first at the scheduler module.
It has four variables which are used to keep track of progress when executing the algorithm.
The purpose of each variable is explained in the comments in the PRISM file.
The commands of the module show how these variables are updated at each step
and again the comments in the PRISM file
describe the correspondence between the algorithm and the PRISM model.
</p>
<li><p>
The scheduler module controls the behaviour of each party by synchronising with them.
Note the labels <span class="prismident">receiveA</span> and <span class="prismident">receiveB</span>
at the start of the commands in the scheduler module (and also in the corresponding party modules).
This means that at each step, one of the parties (<em>A</em> or <em>B</em>) will perform a command simultaneously 
with the scheduler.
</p>
<li><p>
The module for party <em>A</em> keeps track of the number of bits
of each secret of <em>B</em>'s that <em>A</em> has received from <em>B</em>
(and vice versa for the module representing party <em>B</em>).
The code above can be used for the case with <span class="prismident">N</span>=10 pairs of secrets.
In fact, it can also be used for any value of <span class="prismident">N</span> less than 10.
In these cases, we only actually use the variables
<span class="prismident">b1_i</span> and <span class="prismident">b2_i</span>
for <span class="prismident">i</span>&lt;<span class="prismident">N</span>.
</p></ul>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Download the model <b>egl.pm</b> from above and load it into PRISM.
Check for the green tick indicating that model has loaded and parsed correctly.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Using a fairly small value of <span class="prismident">N</span> (say 4),
generate a random path through the model using the simulator.
You should find that the path stops after about 40 steps
(when the contract signing algorithm ends).
Look at the values of the first 4 variables
in the table representing the path.
Check that this matches your understanding of how the algorithm works.
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>2. Analysing a weakness of the algorithm</h3>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Load the following properties file into PRISM:
</p>

<?php prism_code("egl/egl.pctl") ?>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Study the properties file above.
There are two labels, used to identify certain important states of the model,
and then two properties.
The first property gives the probability, from the initial state of the model,
of reaching a state where <em>B</em> knows a pair of <em>A</em>'s secrets and <em>A</em> does not know one of <em>B</em>'s.
This is a measure of how likely the algorithm is to be unfair towards party <em>A</em>.
The second property is the same, but with two parties reversed.
<p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
At this point, you should modify some of the settings in PRISM.
This will make verification much more efficient on this example.
Launch the "Options" dialog from the main menu.
Firstly, change the "engine"  from "hybrid" to "MTBDD".
Secondly, change the "use precomputation" option from "yes" to "no".
Note that when you exit PRISM later,
you will asked whether you want to save these changes to the options. Select "No".
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Plot the results of the first property for <span class="prismident">N</span>=1..10.
Plot the results for the second property for the same range on the same graph.
The graph should look something like this:
</p>

<img class="prism-image" src="images/tutorial.egl-graph1.png" alt="Probability that a party is disadvantaged">

<p>
The interpretation is that, for any value of <span class="prismident">N</span>,
with probability 1, party <em>B</em> eventually knows a pair of secrets when <em>A</em> does not.
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>3. Improving the algorithm: EGL2</h3>

<p>
We will now model an improved version of the algorithm.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Look at  the <a href="http://web.comlab.ox.ac.uk/teaching/materials08-09/probabilistic/07-costs%20rewards.pdf">slides</a>
or <a href="http://web.comlab.ox.ac.uk/teaching/materials08-09/probabilistic/07-costs%20rewards-handout.pdf">handout</a>
from lecture 7 to understand the difference between EGL2 and the original algorithm EGL.
</p>

<p>
We only need to change the scheduler module and, more specifically,
only the commands which control the second and third phases of the algorithm.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Save a new copy the model file as <b>egl2.pm</b> and then modify this new file,
replacing this code in the original model:
</p>

<pre class="prism-code">
	<span class="prismcomment">// SECOND AND THIRD PHASES (interleaved for A and B):</span>
	
	<span class="prismcomment">// A sends bth bit of nth secret (for  n=1..N-1), move to next secret</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span>-&gt; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>);
	<span class="prismcomment">// A sends bth bit of Nth secret, move to next phase (N+1..2N)</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">3</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>); 
	<span class="prismcomment">// A sends bth bit of (N+n)th secret (for  n=1..N-1), move to next secret</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span>-&gt; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>);
	<span class="prismcomment">// A sends bth bit of last (2Nth) secret, B will go next</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">2</span>) &amp; (<span class="prismident">party'</span>=<span class="prismnum">2</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>);
	
	<span class="prismcomment">// B sends bth bit of nth secret (for  n=1..N-1), move to next secret</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>);
	<span class="prismcomment">// B sends bth bit of Nth secret, move to next phase (N+1..2N)</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">3</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>);
	<span class="prismcomment">// B sends bth bit of (N+n)th secret (for  n=1..N-1), move to next secret</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>);
	<span class="prismcomment">// B sends bth bit of last (2Nth) secret, increment b and go back to A</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> &amp; <span class="prismident">b</span>&lt;<span class="prismident">L</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">2</span>) &amp; (<span class="prismident">party'</span>=<span class="prismnum">1</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>) &amp; (<span class="prismident">b'</span>=<span class="prismident">b</span>+<span class="prismnum">1</span>);
	<span class="prismcomment">// B sends final (Lth) bit of last (2Nth) secret, protocl is now finished</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> &amp; <span class="prismident">b</span>=<span class="prismident">L</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">4</span>);
</pre>

<p>
with this code:
</p>

<pre class="prism-code">
	<span class="prismcomment">// SECOND AND THIRD PHASES (interleaved for A and B):</span>
	
	<span class="prismcomment">// A sends bth bit of nth secret (for  n=1..N-1), move to next secret</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span>-&gt; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>);
	<span class="prismcomment">// A sends bth bit of Nth secret, B will go next</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">2</span>) &amp; (<span class="prismident">party'</span>=<span class="prismnum">2</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>);
	<span class="prismcomment">// B sends bth bit of nth secret (for  n=1..N-1), move to next secret</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>);
	<span class="prismcomment">// B sends bth bit of Nth secret, move to next phase (N+1..2N) and back to A</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">3</span>) &amp; (<span class="prismident">party'</span>=<span class="prismnum">1</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>);
	<span class="prismcomment">// A sends bth bit of (N+n)th secret (for  n=1..N-1), move to next secret</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span>-&gt; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>);
	<span class="prismcomment">// A sends bth bit of last (2Nth) secret, B will go next</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">3</span>) &amp; (<span class="prismident">party'</span>=<span class="prismnum">2</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>);
	<span class="prismcomment">// B sends bth bit of (N+n)th secret (for  n=1..N-1), move to next secret</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>);
	<span class="prismcomment">// B sends bth bit of last (2Nth) secret, increment b and go back to A</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> &amp; <span class="prismident">b</span>&lt;<span class="prismident">L</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">2</span>) &amp; (<span class="prismident">party'</span>=<span class="prismnum">1</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>) &amp; (<span class="prismident">b'</span>=<span class="prismident">b</span>+<span class="prismnum">1</span>);
	<span class="prismcomment">// B sends final (Lth) bit of last (2Nth) secret, protocol is now finished</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> &amp; <span class="prismident">b</span>=<span class="prismident">L</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">4</span>);
</pre>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Now reload the property file <b>egl.pctl</b> used before
and plot the results for the first property for the same range of <span class="prismident">N</span> (1..10) on the same graph.
Do the same for the second property.
You should get something like this:
</p>

<img class="prism-image" src="images/tutorial.egl-graph2.png" alt="Probability that a party is disadvantaged">

<p>
We see that, for small values of <span class="prismident">N</span>,
the improved algorithm (EGL2) is better, i.e. less likely to be unfair to party <em>A</em>.
For larger values of <span class="prismident">N</span>, however,
there is very little improvement.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Save your graph (export as a "PRISM graph").
This will allow you to reload it and add to it later.
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>4. Two more versions: EGL3 and EGL4</h3>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Look at the other 2 versions of the algorithm, EGL3 and EGL4,
as described in lecture 7 (<a href="http://web.comlab.ox.ac.uk/teaching/materials08-09/probabilistic/07-costs%20rewards.pdf">slides</a>
and <a href="http://web.comlab.ox.ac.uk/teaching/materials08-09/probabilistic/07-costs%20rewards-handout.pdf">handout</a>).
Create two new model files, <b>egl3.pm</b> and <b>egl4.pm</b> which model these versions in PRISM.
As for modelling EGL2 above, you only need to change one part of the file,
corresponding to phases 2 and 3 of the scheduler module. <b>[*]</b>
</p>

<p>
Some tips:
</p>

<ul class="prism-list">
<li>A red cross at the top-left of the model editor indicates a parse error - probably a mistake in the syntax.
Position the mouse over the cross to see the error. Alternatively, select menu option "Model | Parse model".
<li>If you want, you can edit the PRISM model in a different text editor.
Use menu option "Model | Reload model" (Ctrl-R) to reload it.
<li>Use the simulator to generate some random traces through your model.
This is the easiest way of debugging your model.
Does the trace seem to match the for loop(s) you are trying to model?
If not, select the step where it goes wrong, look at which transition occured at this point and try to work out what is wrong.
</ul>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Once you have a working model for EGL3 or EGL4 that you think is right,
plot the two properties from above on your existing graph for EGL and EGL2. <b>[*]</b>
</p>

<p>
The correct graph is shown below.
</p>

<img class="prism-image" src="images/tutorial.egl-graph3.png" alt="Probability that a party is disadvantaged">

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>5. Other properties of the algorithm(s)</h3>

<p>
There are several other properties which can be investigated for these algorithms.
These use the costs and rewards capabilities of PRISM
(see <a href="/manual/ThePRISMLanguage/CostsAndRewards">here</a> and
<a href="/manual/PropertySpecification/SpecificationOfReward-basedProperties">here</a> for details on how to specify rewards).
</p>

<p>
One example from the lecture is
"the expected number of messages from <em>B</em> (<em>A</em>) that <em>A</em> (<em>B</em>) needs
to knows a pair once <em>B</em> (<em>A</em>) knows a pair</b>".
This measure can be interpreted as an indication of how much influence
a corrupted party has on the fairness of the protocol, since a corrupted
party can try and delay these messages in order to gain an advantage.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
To find "the expected number of messages from <em>A</em> that <em>B</em> needs to knows a pair once <em>A</em> knows a pair", we
first add the following reward structure to the PRISM description:
</p>

<pre class="prism-code">
<span class="prismkeyword">rewards</span> "<span class="prismident">messages_A_needs</span>"
	[<span class="prismident">receiveA</span>] <span class="prismident">kB</span> &amp; !<span class="prismident">kA</span> : <span class="prismnum">1</span>;
<span class="prismkeyword">endrewards</span>
</pre>
<p>
and then verify the formula <span class="prismkeyword">R</span>{"<span class="prismident">messages_A_needs</span>"}=?[<span class="prismkeyword">F</span> <span class="prismident">phase</span>=<span class="prismnum">4</span>].
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Modify this reward structure to analyse
"the expected number of messages from <em>B</em> that <em>A</em> needs to knows a pair once <em>B</em> knows a pair".
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
On a single graph, for both properties, plot the results for the four variants of the protocol as <span class="prismident">N</span> varies between 1 and 10.
</p>

<p>
The correct graph is shown below.
</p>

<img class="prism-image" src="images/tutorial.egl-graph4.png" alt="plot: expected number of messages from B (A) that A (B) needs to knows a pair once B (A) knows a pair">

<br>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Construct an appropriate reward structure and property for:
"the expected number of messages until both parties know a pair".
Plot the results for all versions of the protocol
as  <span class="prismident">N</span> varies between 1 and 10.
<b>[*]</b>


<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Construct appropriate reward structures and properties for:
<ul>
<li>
"the expected number of pairs of secrets known by party <em>A</em> after <span class="prismident">K</span> steps of the protocol";
<li>
"the expected number of pairs of secrets known by party <em>B</em> after <span class="prismident">K</span> steps of the protocol".
</ul>
Plot results for both the first and fourth versions of the protocol when <span class="prismident">N</span>=5
as <span class="prismident">K</span> varies between 20 and 50.
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>Practical Report</h3>

<p>
To get this practical signed off,
you should provide the demonstrator with a brief practical report
comprising the starred items from the text above, i.e.:
<ol>
<li> from part 4: PRISM code fragments for EGL3 and EGL4 (i.e. the modified module "scheduler" of the PRISM model);
<li> from part 4: the corresponding graph showing the first property on all four EGL models;
<li> from part 5: a reward structure and property for computing "the expected number of messages until both parties know a pair".
</ol>

</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<p>
[ <a href="index.php">Back to index</a> ]
</p>


<!-------------------------------------------------------------------------------->

<?php require '../../includes/footer.php'; ?>
