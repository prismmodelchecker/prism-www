<?php $title = "Probabilistic Model Checking - Practicals - Practical 2"; $nav = "doc"; $nav2 = "tutorial"; require '../../includes/header.php'; ?>

<!-- ============================================================================ -->

<h1><a href="index.php">Probabilistic Model Checking Practicals</a></h1>

<h3>Practical 3</h3>

<p>
This practical concerns using the PRISM tool for the specification and analysis of continuous-time Markov chain (CTMC) models. 
</p>

<p>
Items that should be included in your practical report are
marked with a <b>[*]</b> below
(and also summarised at the end of this page).
</p>

<!-- ============================================================================ -->

<div class="prism-rule"></div>

<h3>1. Dynamic power management (DPM) schemes</h3>

<p>
In this third practical we are going to model and analyse dynamic power management (DPM) schemes.
A DPM scheme is a set of instructions used to switch between different power states of a computing device.
Our model of a DPM system comprises three components:
</p>

<ul>
<li>
the <em>Service Queue (SQ)</em> into which requests for a particular service are placed;
<li>
the <em>Service Provider (SP)</em> which responds to these requests;
<li>
the <em>Power Manager (PM)</em> which controls the Service Provider.
</ul>

<p>
We are going to consider a specific DPM system in which the service provider is a Fujitsu disk drive with 3 power states.
In this case the SQ corresponds to read/write requests to the disk
and, as stated, the SP is the actual disk drive with the power states: <em>sleep</em>, <em>idle</em> and <em>busy</em>.
The power states of the drive have different power consumptions and also different response times to service requests.
</p>

<p>
Switches between power states are either performed by the Service Provider itself
or initiated by the Power Manager.
The SP controls switches between the <em>idle</em> and <em>busy</em> states.
A switch from <em>idle</em> to <em>busy</em> occurs when a request arrives
and a switch from <em>busy</em> to <em>idle</em> occurs when the final request in the queue is served.
Switches between the <em>sleep</em> power state and the <em>idle</em> and <em>busy</em> states are under the control of the PM.
The aim of the PM is to switch between these states such that power consumption
is kept as low as possible whilst maintaining an acceptable level of service.
</p>

<p>
Our initial PRISM model is the following:
</p>

<?php prism_code("power/power.sm") ?>

<p>
This model is a continuous-time Markov chain (CTMC),
as denoted by the keyword at the start of the file.
Presently, we just have two modules, representing the Service Queue (SQ) and Service Provider (SP).
There are a couple of important things to note.
</p>

<p>
Firstly, since this is a CTMC, updates in guarded commands are labelled with rates, not probabilities.
The first command in the module <span class="prismident">SQ</span>, for example,
which describes the arrival of a request into the queue,
has the rate <span class="prismident">rate_arrive</span>,
which is constant defined just above in the file.
</p>

<p>
Secondly, notice that all the commands are labelled with actions
(in square brackets at the start of the line).</a>
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Read the section on <a href="/manual/ThePRISMLanguage/Synchronisation">synchronisation</a> in the manual.
Then, have a look at the definition of the <span class="prismident">SQ</span>
and <span class="prismident">SP</span> modules,
and try to understand what they describe.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Download the model file <b>power.sm</b> from above and load it into PRISM.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Use the PRISM simulator to generate some random paths through the model.
Notice how, for a CTMC model like this, the elapsed time as the path progresses is displayed in the table.
You will probably find that the size of the queue (<span class="prismident">q</span>)
never gets above 1. Why is this?
Generate a path by hand where the queue reaches its maximum size (currently <span class="prismident">q_max</span>=20).
What happens when more requests arrive while the queue is full?
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
What is the size of the state space of this model?
(i.e from the initial state, how many possible different states can be reached?)
Go back to the "Model" tab of the GUI, select menu option "Model | Build model"
and then look at the statistics displayed in the bottom left corner to check your answer.
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>2. Adding the power management control</h3>

<p>
We now extend our PRISM model by adding a Power Manager (PM) component.
The PM functions by observing the state of the system (i.e. the SQ and the SP)
and, based on this, instructs the SP when to change between the <em>sleep</em> power state and the <em>idle</em> and <em>busy</em> states.
In PRISM, we will model this via synchronisation between the existing
<span class="prismident">SP</span> module and a new module called <span class="prismident">PM</span>.
We will use the actions <span class="prismident">idle2sleep</span> and <span class="prismident">sleep2idle</span>
which tell the SP to move between its <em>sleep</em> and <em>idle</em> power states.
Here is the PRISM code for the model extended with the <span class="prismident">PM</span> module.
</p>

<?php prism_code("power/power_policy1.sm") ?>

<p>
The PM needs a <em>policy</em> in order to operate:
a set of rules which dictate what power management instructions to send and when.
This simple policy is to switch out of <em>sleep</em> mode when the request queue exceeds a certain size
(denoted by the constant <span class="prismident">q_trigger</span>)
and to switch back to <em>sleep</em> mode when the queue is empty.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Look at the code we have added to the <span class="prismident">SP</span> module
and at the new <span class="prismident">PM</span> module.
Make sure you understand how they work.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Now use the simulator to generate a trace through this new model.
When you create a new path, you have to specify a value for the constant <span class="prismident">q_trigger</span>,
because it is left undefined in the model. Try a value of 5 for now.
Also, PRISM remembers the initial state for the previous model,
so you will need to change the initial state slightly -
make sure both <span class="prismident">q</span> and <span class="prismident">sp</span> are set to 0,
i.e. initially the queue is empty and the SP is in <em>sleep</em> mode.
Does this new model behave as you expect?
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>3. Analysing probabilistic performance measures</h3>

<p>
We will now use PRISM to analyse the behaviour of the power management system.
More specifically, we will first study the probability that the service queue is full at a particular time instant.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Go to the "Properties" tab of the GUI,
create a new constant called <span class="prismident">T</span>,
of type double and with no defined value.
Then add the following property:
</p>

<pre class="prism-code">
<span class="prismkeyword">P</span>=? [ <span class="prismkeyword">F</span>[<span class="prismident">T</span>,<span class="prismident">T</span>] <span class="prismident">q</span>=<span class="prismident">q_max</span> ]
</pre>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Now, create an <a href="/manual/RunningPRISM/Experiments">experiment</a>
based on this property, plotting a graph of its result for
<span class="prismident">q_trigger</span> equal to 5
and <span class="prismident">T</span> from 0 up to 20,
i.e. for the first 20 seconds of the system.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
It seems that the transient probability of the queue being full stabilises after a short while.
Using another experiment, plot values for the same property on the same graph,
this time for <span class="prismident">T</span> from 20 up to 40,
and see if the probability remains the same.
To confirm this, now create a property to check the long-run probability of the queue being full,
using the <a href="/manual/PropertySpecification/TheSOperator">S operator</a>.
Right click the new property and select "Verify".
You will need to give a value for <span class="prismident">T</span>
but this is not used so you can enter anything.
It turns out that the default iterative method in PRISM (Jacobi) for solving this kind of property
does not converge in this case. Switch to the Gauss-Seidel method from the "Options" dialog and try again.
Check that your result matches the graph.
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>4. Analysing reward-based performance measures</h3>

<p>
Next, we will study reward based properties
using PRISM's support for costs and rewards.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Read the section on
<a href="/manual/ThePRISMLanguage/CostsAndRewards">costs and rewards</a>
in the manual.
Then, look at the rewards that have already been defined in this model.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Add these two properties which can be used to compute the transient and long-run expected queue size, respectively:
</p>

<pre class="prism-code">
<span class="prismkeyword">R</span>{"<span class="prismident">queue_size</span>"}=? [ <span class="prismkeyword">I</span>=<span class="prismident">T</span> ]
<span class="prismkeyword">R</span>{"<span class="prismident">queue_size</span>"}=? [ <span class="prismkeyword">S</span> ]
</pre>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Plot the expected queue size at time <span class="prismident">T</span>,
for the first 20 seconds of the model.
As above, also compute the long-run value and check that it matches the results on the graph.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Now create some experiments to analyse the transient and/or long-run expected queue size
for a range of different values of the constant <span class="prismident">q_trigger</span>.
How does the performance of the system vary as this changes?
What is the "best" value of <span class="prismident">q_trigger</span>?
</p>

<p>
Another possible measure of the performance of the system is how many requests get lost,
i.e. how many times a request arrives when the queue is currently full.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Add a second <a href="/manual/ThePRISMLanguage/CostsAndRewards">reward structure</a>
to the model called "lost", which assigns 1 to every transition of the model labelled with
action <span class="prismident">request</span> from a state where the queue is full. <b>[*]</b>
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Now create a new property for checking the expected <em>cumulated</em>
reward up until time <span class="prismident">T</span>. 
How does this measure vary for different values of <span class="prismident">q_trigger</span>? <b>[*]</b>
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>5. Analysing the power consumption</h3>

<p>
So far we have only analysed the performance of the system, i.e. how promptly requests are dealt with
(one measure of which is the expected queue size) and how often requests are lost.
However, there is a trade off between the performance of the system and the power consumption of the system
(to optimise performance one can just keep everything "on", however this approach will consume the most power).
</p>

<p>
The disk drive in our example has the following power consumption:
</p>

<ul>
<li>
energy is used at rate 0.13, 0.95 or 2.15 in the power states <em>sleep</em>, <em>idle</em> and <em>busy</em>, respectively.
<li>
transitions between power states have a fixed energy cost:
going from <em>sleep</em> to <em>idle</em> uses 7.0 units and from <em>idle</em> to <em>sleep</em> uses 0.067 units.
</ul>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Add a third reward structure to the model representing the power consumption.
Use a cumulative reward property to investigate the energy consumption over time of the system. <b>[*]</b>
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
To illustrate the trade off between power consumption and performance, on the same graph plot how 
the long run average queue size and power consumption
vary as <span class="prismident">q_trigger</span> changes. <b>[*]</b>
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>6. Changing the power management scheme</h3>

<p>
Another approach to implementing the power manager is to use <em>stochastic</em> policies,
which can also make random choices.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Replace the <span class="prismident">PM</span> module in the existing model with the following:
</p>

<pre class="prism-code">
<span class="prismcomment">// Probability of ordering the SP to sleep when queue empty</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">double</span> <span class="prismident">p_sleep</span>;

<span class="prismkeyword">module</span> <span class="prismident">PM</span>
	
	<span class="prismcomment">// i2s: true when idle2sleep command should be issued</span>
	<span class="prismident">i2s</span> : <span class="prismkeyword">bool</span> <span class="prismkeyword">init</span> <span class="prismkeyword">false</span>;
	
	<span class="prismcomment">// idle to sleep command triggered by request arrivals/services</span>
	<span class="prismcomment">//  decide to perform command when queue becomes empty with probability p_sleep</span>
	[<span class="prismident">serve_last</span>] <span class="prismkeyword">true</span> -&gt; <span class="prismident">p_sleep</span> : (<span class="prismident">i2s'</span>=<span class="prismkeyword">true</span>) + <span class="prismnum">1</span>-<span class="prismident">p_sleep</span> : (<span class="prismident">i2s'</span>=<span class="prismkeyword">false</span>);
	<span class="prismcomment">// cancel idle to sleep command if a reqest arrives</span>
	[<span class="prismident">request</span>] <span class="prismkeyword">true</span> -&gt; (<span class="prismident">i2s'</span>=<span class="prismkeyword">false</span>);
	
	<span class="prismcomment">// Send idle2sleep command to SP</span>
	[<span class="prismident">idle2sleep</span>] <span class="prismident">i2s</span> -&gt; (<span class="prismident">i2s'</span>=<span class="prismkeyword">false</span>);
	
	<span class="prismcomment">// Send sleep2idle command to SP (when queue is full)</span>
	[<span class="prismident">sleep2idle</span>] <span class="prismident">q</span>=<span class="prismident">q_max</span> -&gt; <span class="prismkeyword">true</span>;
	
<span class="prismkeyword">endmodule</span>
</pre>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
How well does this power management system perform?
What effect does the value of the probability <span class="prismident">p_sleep</span> have?
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Change this power manager such that, instead of switching on (sending the sleep2idle command to the PM) each time the queue becomes full,
probabilistically chooses to switches on whenever a request arrives where the probability of switching increases as the request queue size increases. <b>[*]</b>
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Does this power management system improve performance or power consumption?
</p>


<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>Practical Report</h3>

<p>
To get this practical signed off,
you should provide the demonstrator with a brief practical report
comprising the starred items from the text above, i.e.:
<ol>
<li> from part 4: the PRISM code fragment for the reward structure "<span class="prismident">lost</span>";
<li> from part 4: the corresponding property and graph for the expected cumulated reward up until time <span class="prismident">T</span>;
<li> from part 5: a reward structure and property for analysing the expected power consumption over time;
<li> from part 5: a graph showing the trade off between power consumption and performance (expected queue size);
<li> from part 6: the PRISM code fragment for the new power manager that probabilistically switches on the disk drive.
</ol>

</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>


<p>
[ <a href="index.php">Back to index</a> ]
</p>

<!-------------------------------------------------------------------------------->

<?php require '../../includes/footer.php'; ?>
