dtmc

const double p; // Parameter: probability send in the next slot

formula less_than_two_sent = ... ;
formula two_or_more_sent = ... ;

module destination

    d : [0..1] init 0; // Local state: 0=receiving, 1=sending feedback
    coll : bool init false; // Whether a collision occurred
    
    // RECEIVING MESSAGES
    [send] d=0 & less_than_two_sent -> (d'=1) & (coll'=false);
    [send] d=0 & two_or_more_sent -> (d'=1) & (coll'=true);

    // SENDING FEEDBACK
    [ok] d=1 & !coll -> (d'=0) & (coll'=false);
    [error] d=1 & coll -> (d'=0) & (coll'=false);

endmodule

// Numbers of messages to be sent by each node
const int M1=1;
...

module node1
    
    // Local state (0=sending, 1=receiving feedback, 2=waiting, 3=finished)
    s1 : [0..3] init 0;
    // Number of messages need to send
    m1 : [0..M1] init M1;

    ...
    
endmodule

...

