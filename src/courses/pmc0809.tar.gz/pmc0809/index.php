<?php $title = "Probabilistic Model Checking - Practicals"; $nav = "doc"; require '../../includes/header.php'; ?>

<!-- ============================================================================ -->

<h1><a href="index.php">Probabilistic Model Checking Practicals</a></h1>

<h3>Michaelmas Term 2008</h3>

<hr>

<p>
These practical exercises are based on the
<a href="http://www.prismmodelchecker.org/">PRISM</a> tool.
This is already installed (under Linux) on the lab machines in room 379.
However, you will be expected to complete some of this work outside of the lab sessions.
You will also require PRISM to complete the take-home assignment at the end of the course.
Therefore, you will mostly likely wish to install a copy of PRISM on your own machine.
Please see either
<a href="http://web.comlab.ox.ac.uk/people/Gethin.Norman/index.html">Gethin Norman</a>
or <a href="http://web.comlab.ox.ac.uk/people/David.Parker/index.html">Dave Parker</a>
as soon as possible 
if you have any problems in this respect.
</p>

<p>
<b>Running PRISM in room 379:</b><br>
There are actually two version of PRISM installed under Linux on these machines.
It is recommended that you use the latest develpment release of PRISM (3.2.r808),
which you can run by typing the following at the command prompt:
<p>
<pre>
~dxp/prism/bin/xprism
</pre>
<p>
The machines also have a slightly older version installed
(the latest publically available release of PRISM, version 3.2)
which is obtained by just typing <tt>xprism</tt>.
Although you can complete all of the practicals using either release,
the newer version (3.2.r808) is significantly easier to use thanks to a new
modelling language editor (amongst other improvements).
</p>

<p>
<b>Installing PRISM on your own machine:</b><br>
See <a href="prism.php">here</a>.

<hr>

<h3>Resources</h3>

<p>
The best source of information about PRISM is the online <a href="/manual/">manual</a>.
</p>

<p>
Outside of the lab sessions,
general questions about PRISM (but not specifically about the exercises, please)
can be sent to the
<a href="http://groups.google.com/group/prismmodelchecker">PRISM discussion group</a>.
</p>

<hr>

<h3>The Practicals</h3>

<p>Links to each of the 4 practical exercises will appear here:</p>

<ul>
<!--<li> <a href="practical1.php">Practical 1</a>-->
<li> <a href="practical1.php">Practical 1</a>
<li> <a href="practical2.php">Practical 2</a>
<li> <a href="practical3.php">Practical 3</a>
<li> <a href="practical4.php">Practical 4</a>
</ul>

<hr>

<br><br><br><br><br><br><br><br><br>

<!-------------------------------------------------------------------------------->

<?php require '../../includes/footer.php'; ?>
