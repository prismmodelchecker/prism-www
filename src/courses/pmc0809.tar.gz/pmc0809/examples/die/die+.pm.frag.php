<span class="prismkeyword">dtmc</span>

<span class="prismkeyword">module</span> <span class="prismident">die</span>

	<span class="prismcomment">// local state</span>
	<span class="prismident">s</span> : [<span class="prismnum">0</span>..<span class="prismnum">7</span>] <span class="prismkeyword">init</span> <span class="prismnum">0</span>;
	<span class="prismcomment">// value of the die</span>
	<span class="prismident">d</span> : [<span class="prismnum">0</span>..<span class="prismnum">6</span>] <span class="prismkeyword">init</span> <span class="prismnum">0</span>;
	
	[] <span class="prismident">s</span>=<span class="prismnum">0</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">1</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">2</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">1</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">3</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">4</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">2</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">5</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">6</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">3</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">1</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">7</span>) &amp; (<span class="prismident">d'</span>=<span class="prismnum">1</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">4</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">7</span>) &amp; (<span class="prismident">d'</span>=<span class="prismnum">2</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">7</span>) &amp; (<span class="prismident">d'</span>=<span class="prismnum">3</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">5</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">7</span>) &amp; (<span class="prismident">d'</span>=<span class="prismnum">4</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">7</span>) &amp; (<span class="prismident">d'</span>=<span class="prismnum">5</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">6</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">2</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">s'</span>=<span class="prismnum">7</span>) &amp; (<span class="prismident">d'</span>=<span class="prismnum">6</span>);
	[] <span class="prismident">s</span>=<span class="prismnum">7</span> -&gt; (<span class="prismident">s'</span>=<span class="prismnum">7</span>);
	
<span class="prismkeyword">endmodule</span>

<span class="prismkeyword">rewards</span> "<span class="prismident">steps</span>"
	<span class="prismkeyword">true</span> : <span class="prismnum">1</span>;
<span class="prismkeyword">endrewards</span>
