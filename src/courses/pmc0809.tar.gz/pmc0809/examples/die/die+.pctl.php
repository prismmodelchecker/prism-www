<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>
die+.pctl
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- Style sheet "prism.css" can be found in the "etc" directory of the PRISM distribution -->
<link type="text/css" rel="stylesheet" href="prism.css">
</head>
<body text="#000000" bgcolor="#ffffff">
<pre>
<span class="prismkeyword">const</span> <span class="prismkeyword">int</span> <span class="prismident">x</span>;

<span class="prismkeyword">P</span>=? [ <span class="prismkeyword">true</span> <span class="prismkeyword">U</span> <span class="prismident">s</span>=<span class="prismnum">7</span> &amp; <span class="prismident">d</span>=<span class="prismident">x</span> ]

<span class="prismkeyword">R</span>=? [ <span class="prismkeyword">F</span> <span class="prismident">s</span>=<span class="prismnum">7</span> ]
</pre>
</body>
</html>
