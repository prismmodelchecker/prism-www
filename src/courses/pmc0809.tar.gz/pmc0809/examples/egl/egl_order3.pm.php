<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>
egl_order3.pm
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- Style sheet "prism.css" can be found in the "etc" directory of the PRISM distribution -->
<link type="text/css" rel="stylesheet" href="prism.css">
</head>
<body text="#000000" bgcolor="#ffffff">
<pre>
<span class="prismcomment">// Randomised protocol for signing contracts taken from:</span>
<span class="prismcomment">// S. Even, O. Goldreich, and A. Lempel.</span>
<span class="prismcomment">// A randomized protocol for signing contracts.</span>
<span class="prismcomment">// Communications of the ACM, 28(6):637 647, 1985.</span>

<span class="prismcomment">// employs ordering 3 for secrets/messages (EGL1)</span>

<span class="prismcomment">// note that: certain variables that belong to a party appear in the other party's module</span>
<span class="prismcomment">// as this leads to a more structured model (without this PRISM runs out of memory)</span>

<span class="prismcomment">//-----------------------------------------------------------------------------------------</span>

<span class="prismkeyword">probabilistic</span> <span class="prismcomment">// model is a DTMC (no non-determinism)</span>


<span class="prismcomment">// CONSTANTS</span>
<span class="prismcomment">// number of secrets the party sends (vary during verification)</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">int</span> <span class="prismident">N</span>;
<span class="prismcomment">// number of bits in each secret (fix at 2)</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">int</span> <span class="prismident">L</span>=<span class="prismnum">2</span>;

<span class="prismcomment">// FORMULAE</span>
<span class="prismcomment">// true when B knows a pair of secrets</span>
<span class="prismkeyword">formula</span> <span class="prismident">kB</span> = ( (<span class="prismident">a1_0</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_0</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">a1_1</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_1</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">a1_2</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_2</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">a1_3</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_3</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">a1_4</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_4</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">a1_5</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_5</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">a1_6</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_6</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">a1_7</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_7</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">a1_8</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_8</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">a1_9</span>=<span class="prismident">L</span>  &amp; <span class="prismident">a2_9</span>=<span class="prismident">L</span>));
<span class="prismcomment">// true when A knows a pair of secrets</span>
<span class="prismkeyword">formula</span> <span class="prismident">kA</span> = ( (<span class="prismident">b1_0</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_0</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">b1_1</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_1</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">b1_2</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_2</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">b1_3</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_3</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">b1_4</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_4</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">b1_5</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_5</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">b1_6</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_6</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">b1_7</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_7</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">b1_8</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_8</span>=<span class="prismident">L</span>)
			 | (<span class="prismident">b1_9</span>=<span class="prismident">L</span>  &amp; <span class="prismident">b2_9</span>=<span class="prismident">L</span>));

<span class="prismcomment">//-----------------------------------------------------------------------------------------</span>
<span class="prismcomment">// module used to order the sending of messages</span>
<span class="prismkeyword">module</span> <span class="prismident">scheduler</span>
	
	<span class="prismident">b</span> : [<span class="prismnum">1</span>..<span class="prismident">L</span>]; <span class="prismcomment">// counter for current bit to be send (used in phases 2 and 3)</span>
	<span class="prismident">n</span> : [<span class="prismnum">0</span>..<span class="prismkeyword">max</span>(<span class="prismident">N</span>-<span class="prismnum">1</span>,<span class="prismnum">1</span>)]; <span class="prismcomment">// counter as parties send N messages in a row</span>
	<span class="prismident">phase</span> : [<span class="prismnum">1</span>..<span class="prismnum">5</span>]; <span class="prismcomment">// phase of the protocol</span>
	<span class="prismident">party</span> : [<span class="prismnum">1</span>..<span class="prismnum">2</span>]; <span class="prismcomment">// which party moves</span>
	<span class="prismcomment">// 1 first phase of the protocol (sending messages of the form OT(.,.,.,.)</span>
	<span class="prismcomment">// 2 and 3 - second phase of the protocol (sending secretes 1..n and n+1..2n respectively)</span>
	<span class="prismcomment">// 4 finished the protocol</span>
	
	<span class="prismcomment">// FIRST PHASE</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> -&gt; (<span class="prismident">party'</span>=<span class="prismnum">2</span>); <span class="prismcomment">// first A sends a message then B does</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">party'</span>=<span class="prismnum">1</span>) &amp; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>); <span class="prismcomment">// after B sends a message we move onto the next message</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">party'</span>=<span class="prismnum">1</span>) &amp; (<span class="prismident">phase'</span>=<span class="prismnum">2</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>); <span class="prismcomment">// B has sent his final message - move to next phase</span>
	<span class="prismcomment">// SECOND AND THIRD PHASES</span>
	
	<span class="prismcomment">// in this case it alternates between A and B</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span>..<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> -&gt; (<span class="prismident">party'</span>=<span class="prismnum">2</span>); <span class="prismcomment">// A transmits bth bit for message i then B does</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span>..<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>) &amp; (<span class="prismident">party'</span>=<span class="prismnum">1</span>); <span class="prismcomment">// after B does we move onto the next secret</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span>..<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> &amp; <span class="prismident">b</span>&lt;<span class="prismident">L</span> -&gt; (<span class="prismident">party'</span>=<span class="prismnum">1</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>) &amp; (<span class="prismident">b'</span>=<span class="prismident">b</span>+<span class="prismnum">1</span>); <span class="prismcomment">// finished for this lot of bits</span>
	[<span class="prismident">receiveB</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span>..<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">1</span> -&gt; (<span class="prismident">party'</span>=<span class="prismnum">2</span>); <span class="prismcomment">// A transmits bth bit for message i then B does</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span>..<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>&lt;<span class="prismident">N</span>-<span class="prismnum">1</span> -&gt; (<span class="prismident">n'</span>=<span class="prismident">n</span>+<span class="prismnum">1</span>) &amp; (<span class="prismident">party'</span>=<span class="prismnum">1</span>); <span class="prismcomment">// after B does we move onto the next secret</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span>..<span class="prismnum">3</span> &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> &amp; <span class="prismident">b</span>&lt;<span class="prismident">L</span> -&gt; (<span class="prismident">party'</span>=<span class="prismnum">1</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>) &amp; (<span class="prismident">b'</span>=<span class="prismident">b</span>+<span class="prismnum">1</span>); <span class="prismcomment">// finished for this lot of bits</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span>    &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> &amp; <span class="prismident">b</span>=<span class="prismident">L</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">3</span>) &amp; (<span class="prismident">party'</span>=<span class="prismnum">1</span>) &amp; (<span class="prismident">n'</span>=<span class="prismnum">0</span>) &amp; (<span class="prismident">b'</span>=<span class="prismnum">1</span>); <span class="prismcomment">// finished for party B move to next phase</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span>    &amp; <span class="prismident">party</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismident">N</span>-<span class="prismnum">1</span> &amp; <span class="prismident">b</span>=<span class="prismident">L</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">4</span>); <span class="prismcomment">// finished protocol (reveal values)</span>
	
	<span class="prismcomment">// FINISHED</span>
	[] <span class="prismident">phase</span>=<span class="prismnum">4</span> -&gt; (<span class="prismident">phase'</span>=<span class="prismnum">4</span>); <span class="prismcomment">// loop</span>
	
<span class="prismkeyword">endmodule</span>

<span class="prismcomment">// party A</span>
<span class="prismkeyword">module</span> <span class="prismident">partyA</span>
	
	<span class="prismcomment">// bi_j the number of bits of B's i*jth secret A knows </span>
	<span class="prismcomment">// (keep pairs of secrets together to give a more structured model)</span>
	<span class="prismident">b1_0</span>  : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_0</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_1</span>  : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_1</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_2</span>  : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_2</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_3</span>  : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_3</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_4</span>  : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_4</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_5</span>  : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_5</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_6</span>  : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_6</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_7</span>  : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_7</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_8</span>  : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_8</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	<span class="prismident">b1_9</span>  : [<span class="prismnum">0</span>..<span class="prismident">L</span>]; <span class="prismident">b2_9</span> : [<span class="prismnum">0</span>..<span class="prismident">L</span>];
	
	
	<span class="prismcomment">// first step (get either secret i or (N-1)+i with equal probability)</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">0</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_0'</span>=<span class="prismident">L</span>)  + <span class="prismnum">0.5</span> : (<span class="prismident">b2_0'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">1</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_1'</span>=<span class="prismident">L</span>)  + <span class="prismnum">0.5</span> : (<span class="prismident">b2_1'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">2</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_2'</span>=<span class="prismident">L</span>)  + <span class="prismnum">0.5</span> : (<span class="prismident">b2_2'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">3</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_3'</span>=<span class="prismident">L</span>)  + <span class="prismnum">0.5</span> : (<span class="prismident">b2_3'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">4</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_4'</span>=<span class="prismident">L</span>)  + <span class="prismnum">0.5</span> : (<span class="prismident">b2_4'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">5</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_5'</span>=<span class="prismident">L</span>)  + <span class="prismnum">0.5</span> : (<span class="prismident">b2_5'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">6</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_6'</span>=<span class="prismident">L</span>)  + <span class="prismnum">0.5</span> : (<span class="prismident">b2_6'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">7</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_7'</span>=<span class="prismident">L</span>)  + <span class="prismnum">0.5</span> : (<span class="prismident">b2_7'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">8</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_8'</span>=<span class="prismident">L</span>)  + <span class="prismnum">0.5</span> : (<span class="prismident">b2_8'</span>=<span class="prismident">L</span>);
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">1</span> &amp; <span class="prismident">n</span>=<span class="prismnum">9</span>  -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">b1_9'</span>=<span class="prismident">L</span>)  + <span class="prismnum">0.5</span> : (<span class="prismident">b2_9'</span>=<span class="prismident">L</span>);
	<span class="prismcomment">// second step (secrets 0,...,N-1)</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">0</span>  -&gt; (<span class="prismident">b1_0'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_0</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">1</span>  -&gt; (<span class="prismident">b1_1'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_1</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">2</span>  -&gt; (<span class="prismident">b1_2'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_2</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">3</span>  -&gt; (<span class="prismident">b1_3'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_3</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">4</span>  -&gt; (<span class="prismident">b1_4'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_4</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">5</span>  -&gt; (<span class="prismident">b1_5'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_5</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">6</span>  -&gt; (<span class="prismident">b1_6'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_6</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">7</span>  -&gt; (<span class="prismident">b1_7'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_7</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">8</span>  -&gt; (<span class="prismident">b1_8'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_8</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">2</span> &amp; <span class="prismident">n</span>=<span class="prismnum">9</span>  -&gt; (<span class="prismident">b1_9'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b1_9</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	<span class="prismcomment">// second step (secrets N,...,2N-1)</span>
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">0</span>  -&gt; (<span class="prismident">b2_0'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_0</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">1</span>  -&gt; (<span class="prismident">b2_1'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_1</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">2</span>  -&gt; (<span class="prismident">b2_2'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_2</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">3</span>  -&gt; (<span class="prismident">b2_3'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_3</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">4</span>  -&gt; (<span class="prismident">b2_4'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_4</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">5</span>  -&gt; (<span class="prismident">b2_5'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_5</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">6</span>  -&gt; (<span class="prismident">b2_6'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_6</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">7</span>  -&gt; (<span class="prismident">b2_7'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_7</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">8</span>  -&gt; (<span class="prismident">b2_8'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_8</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));
	[<span class="prismident">receiveA</span>] <span class="prismident">phase</span>=<span class="prismnum">3</span> &amp; <span class="prismident">n</span>=<span class="prismnum">9</span>  -&gt; (<span class="prismident">b2_9'</span>=<span class="prismkeyword">min</span>(<span class="prismident">b2_9</span>+<span class="prismnum">1</span>,<span class="prismident">L</span>));

<span class="prismkeyword">endmodule</span>

<span class="prismcomment">// construct module for party B through renaming</span>
<span class="prismkeyword">module</span> <span class="prismident">partyB</span>=<span class="prismident">partyA</span>[<span class="prismident">b1_0</span>=<span class="prismident">a1_0</span> ,<span class="prismident">b1_1</span>=<span class="prismident">a1_1</span> ,<span class="prismident">b1_2</span>=<span class="prismident">a1_2</span> ,<span class="prismident">b1_3</span>=<span class="prismident">a1_3</span> ,<span class="prismident">b1_4</span>=<span class="prismident">a1_4</span> ,<span class="prismident">b1_5</span>=<span class="prismident">a1_5</span> ,<span class="prismident">b1_6</span>=<span class="prismident">a1_6</span> ,<span class="prismident">b1_7</span>=<span class="prismident">a1_7</span> ,<span class="prismident">b1_8</span>=<span class="prismident">a1_8</span> ,<span class="prismident">b1_9</span>=<span class="prismident">a1_9</span>,
                     <span class="prismident">b2_0</span>=<span class="prismident">a2_0</span> ,<span class="prismident">b2_1</span>=<span class="prismident">a2_1</span> ,<span class="prismident">b2_2</span>=<span class="prismident">a2_2</span> ,<span class="prismident">b2_3</span>=<span class="prismident">a2_3</span> ,<span class="prismident">b2_4</span>=<span class="prismident">a2_4</span> ,<span class="prismident">b2_5</span>=<span class="prismident">a2_5</span> ,<span class="prismident">b2_6</span>=<span class="prismident">a2_6</span> ,<span class="prismident">b2_7</span>=<span class="prismident">a2_7</span> ,<span class="prismident">b2_8</span>=<span class="prismident">a2_8</span> ,<span class="prismident">b2_9</span>=<span class="prismident">a2_9</span>,
                     <span class="prismident">receiveA</span>=<span class="prismident">receiveB</span>] 
<span class="prismkeyword">endmodule</span>
</pre>
</body>
</html>
