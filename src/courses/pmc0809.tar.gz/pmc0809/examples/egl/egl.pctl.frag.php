<span class="prismcomment">// Party B knows a pair of A's secrets (i.e. has</span>
<span class="prismcomment">// all L bits for at least one of the secrets)</span>
<span class="prismkeyword">label</span> "<span class="prismident">knowB</span>" = ( (<span class="prismident">a1_0</span>=<span class="prismident">L</span> &amp; <span class="prismident">a2_0</span>=<span class="prismident">L</span>)
                | (<span class="prismident">a1_1</span>=<span class="prismident">L</span> &amp; <span class="prismident">a2_1</span>=<span class="prismident">L</span>)
                | (<span class="prismident">a1_2</span>=<span class="prismident">L</span> &amp; <span class="prismident">a2_2</span>=<span class="prismident">L</span>)
                | (<span class="prismident">a1_3</span>=<span class="prismident">L</span> &amp; <span class="prismident">a2_3</span>=<span class="prismident">L</span>)
                | (<span class="prismident">a1_4</span>=<span class="prismident">L</span> &amp; <span class="prismident">a2_4</span>=<span class="prismident">L</span>)
                | (<span class="prismident">a1_5</span>=<span class="prismident">L</span> &amp; <span class="prismident">a2_5</span>=<span class="prismident">L</span>)
                | (<span class="prismident">a1_6</span>=<span class="prismident">L</span> &amp; <span class="prismident">a2_6</span>=<span class="prismident">L</span>)
                | (<span class="prismident">a1_7</span>=<span class="prismident">L</span> &amp; <span class="prismident">a2_7</span>=<span class="prismident">L</span>)
                | (<span class="prismident">a1_8</span>=<span class="prismident">L</span> &amp; <span class="prismident">a2_8</span>=<span class="prismident">L</span>)
                | (<span class="prismident">a1_9</span>=<span class="prismident">L</span> &amp; <span class="prismident">a2_9</span>=<span class="prismident">L</span>));

<span class="prismcomment">// Party A knows a pair of B's secrets (i.e. has</span>
<span class="prismcomment">// all L bits for at least one of the secrets)</span>
<span class="prismkeyword">label</span> "<span class="prismident">knowA</span>" = ( (<span class="prismident">b1_0</span>=<span class="prismident">L</span> &amp; <span class="prismident">b2_0</span>=<span class="prismident">L</span>)
                | (<span class="prismident">b1_1</span>=<span class="prismident">L</span> &amp; <span class="prismident">b2_1</span>=<span class="prismident">L</span>)
                | (<span class="prismident">b1_2</span>=<span class="prismident">L</span> &amp; <span class="prismident">b2_2</span>=<span class="prismident">L</span>)
                | (<span class="prismident">b1_3</span>=<span class="prismident">L</span> &amp; <span class="prismident">b2_3</span>=<span class="prismident">L</span>)
                | (<span class="prismident">b1_4</span>=<span class="prismident">L</span> &amp; <span class="prismident">b2_4</span>=<span class="prismident">L</span>)
                | (<span class="prismident">b1_5</span>=<span class="prismident">L</span> &amp; <span class="prismident">b2_5</span>=<span class="prismident">L</span>)
                | (<span class="prismident">b1_6</span>=<span class="prismident">L</span> &amp; <span class="prismident">b2_6</span>=<span class="prismident">L</span>)
                | (<span class="prismident">b1_7</span>=<span class="prismident">L</span> &amp; <span class="prismident">b2_7</span>=<span class="prismident">L</span>)
                | (<span class="prismident">b1_8</span>=<span class="prismident">L</span> &amp; <span class="prismident">b2_8</span>=<span class="prismident">L</span>)
                | (<span class="prismident">b1_9</span>=<span class="prismident">L</span> &amp; <span class="prismident">b2_9</span>=<span class="prismident">L</span>));

<span class="prismcomment">// What is the probability (from the initial state)</span>
<span class="prismcomment">// of reaching a state where B knows a pair and A does not?</span>
<span class="prismkeyword">P</span>=?[ <span class="prismkeyword">true</span> <span class="prismkeyword">U</span> !"<span class="prismident">knowA</span>" &amp; "<span class="prismident">knowB</span>" ]

<span class="prismcomment">// What is the probability (from the initial state)</span>
<span class="prismcomment">// of reaching a state where B knows a pair and A does not?</span>
<span class="prismkeyword">P</span>=?[ <span class="prismkeyword">true</span> <span class="prismkeyword">U</span> "<span class="prismident">knowA</span>" &amp; !"<span class="prismident">knowB</span>" ]
