<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>
circadian_complete.sm
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- Style sheet "prism.css" can be found in the "etc" directory of the PRISM distribution -->
<link type="text/css" rel="stylesheet" href="prism.css">
</head>
<body text="#000000" bgcolor="#ffffff">
<pre>
<span class="prismcomment">// stochastic model of circadian clock based on ODE model of</span>
<span class="prismcomment">// J. Vilar et al. Mechanisms of Noise-Resistance in Genetic Oscillators</span>
<span class="prismcomment">// Proc. National Academy of Sciences of the United States of America, 99(9):5988-5992, 2002</span>
<span class="prismcomment">// dxp/gxn 24/04/08</span>

<span class="prismkeyword">ctmc</span>

<span class="prismcomment">// generic bound (for species with potentially unbounded quantities)</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">int</span> <span class="prismident">N</span>=<span class="prismnum">1000000</span>; 

<span class="prismcomment">//--------------------------------------------------------</span>
<span class="prismcomment">// activator modules</span>

<span class="prismcomment">// add constant to change the initial number of activator genes</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">int</span> <span class="prismident">M</span>;

<span class="prismkeyword">module</span> <span class="prismident">activator_gene</span>
	
	<span class="prismident">da</span> : [<span class="prismnum">0</span>..<span class="prismident">M</span>] <span class="prismkeyword">init</span> <span class="prismident">M</span>; <span class="prismcomment">// amount of activator gene </span>
	<span class="prismident">da_a</span> : [<span class="prismnum">0</span>..<span class="prismident">M</span>]; <span class="prismcomment">// amount of activator gene with activator protein bound</span>
	
	[<span class="prismident">transc_da</span>]   <span class="prismident">da</span>&gt;<span class="prismnum">0</span>   -&gt;   <span class="prismident">da</span> : <span class="prismkeyword">true</span>; <span class="prismcomment">// transcription (gene to mRNA)</span>
	[<span class="prismident">transc_da_a</span>] <span class="prismident">da_a</span>&gt;<span class="prismnum">0</span> -&gt; <span class="prismident">da_a</span> : <span class="prismkeyword">true</span>; <span class="prismcomment">// transcription (gene to mRNA) (activator protein bound to gene)</span>
	[<span class="prismident">bind_a</span>] <span class="prismident">da</span>&gt;<span class="prismnum">0</span> &amp; <span class="prismident">da_a</span>&lt;<span class="prismident">M</span> -&gt;   <span class="prismident">da</span> : (<span class="prismident">da'</span>=<span class="prismident">da</span>-<span class="prismnum">1</span>) &amp; (<span class="prismident">da_a'</span>=<span class="prismident">da_a</span>+<span class="prismnum">1</span>); <span class="prismcomment">// binds with activator protein</span>
	[<span class="prismident">rel_a</span>]  <span class="prismident">da</span>&lt;<span class="prismident">M</span> &amp; <span class="prismident">da_a</span>&gt;<span class="prismnum">0</span> -&gt; <span class="prismident">da_a</span> : (<span class="prismident">da'</span>=<span class="prismident">da</span>+<span class="prismnum">1</span>) &amp; (<span class="prismident">da_a'</span>=<span class="prismident">da_a</span>-<span class="prismnum">1</span>); <span class="prismcomment">// unbinds from activator protein</span>
	
<span class="prismkeyword">endmodule</span>

<span class="prismkeyword">module</span> <span class="prismident">activator_mRNA</span>
	
	<span class="prismident">ma</span> : [<span class="prismnum">0</span>..<span class="prismident">N</span>]; <span class="prismcomment">// amount of activator mRNA</span>
	
	[<span class="prismident">transc_da</span>]   <span class="prismident">ma</span>&lt;<span class="prismident">N</span> -&gt; (<span class="prismident">ma'</span>=<span class="prismident">ma</span>+<span class="prismnum">1</span>); <span class="prismcomment">// transcription (gene to mRNA)</span>
	[<span class="prismident">transc_da_a</span>] <span class="prismident">ma</span>&lt;<span class="prismident">N</span> -&gt; (<span class="prismident">ma'</span>=<span class="prismident">ma</span>+<span class="prismnum">1</span>); <span class="prismcomment">// transcription (gene to mRNA) (activator protein bound to gene) </span>
	[<span class="prismident">transl_a</span>] <span class="prismident">ma</span>&gt;<span class="prismnum">0</span> -&gt; <span class="prismident">ma</span> : <span class="prismkeyword">true</span>; <span class="prismcomment">// translation (mRNA to protein)</span>
	[<span class="prismident">deg_ma</span>] <span class="prismident">ma</span>&gt;<span class="prismnum">0</span> -&gt; <span class="prismident">ma</span> : (<span class="prismident">ma'</span>=<span class="prismident">ma</span>-<span class="prismnum">1</span>); <span class="prismcomment">// mRNA degrades</span>
	
<span class="prismkeyword">endmodule</span>

<span class="prismkeyword">module</span> <span class="prismident">activator_protein</span>
	
	<span class="prismident">a</span>  : [<span class="prismnum">0</span>..<span class="prismident">N</span>]; <span class="prismcomment">// amount of activator protein</span>
	
	[<span class="prismident">transl_a</span>] <span class="prismident">a</span>&lt;<span class="prismident">N</span> -&gt; (<span class="prismident">a'</span>=<span class="prismident">a</span>+<span class="prismnum">1</span>); <span class="prismcomment">// translation (mRNA to protein)</span>
	[<span class="prismident">bind_a</span>] <span class="prismident">a</span>&gt;<span class="prismnum">0</span> -&gt; <span class="prismident">a</span> : (<span class="prismident">a'</span>=<span class="prismident">a</span>-<span class="prismnum">1</span>); <span class="prismcomment">// protein binds with activator gene</span>
	[<span class="prismident">bind_r</span>] <span class="prismident">a</span>&gt;<span class="prismnum">0</span> -&gt; <span class="prismident">a</span> : (<span class="prismident">a'</span>=<span class="prismident">a</span>-<span class="prismnum">1</span>); <span class="prismcomment">// protein binds with repressor gene</span>
	[<span class="prismident">rel_a</span>] <span class="prismident">a</span>&lt;<span class="prismident">N</span> -&gt; (<span class="prismident">a'</span>=<span class="prismident">a</span>+<span class="prismnum">1</span>); <span class="prismcomment">// unbinds from activator gene</span>
	[<span class="prismident">rel_r</span>] <span class="prismident">a</span>&lt;<span class="prismident">N</span> -&gt; (<span class="prismident">a'</span>=<span class="prismident">a</span>+<span class="prismnum">1</span>); <span class="prismcomment">// unbinds from repressor gene</span>
	[<span class="prismident">deg_a</span>]   <span class="prismident">a</span>&gt;<span class="prismnum">0</span> -&gt;  <span class="prismident">a</span> : (<span class="prismident">a'</span>=<span class="prismident">a</span>-<span class="prismnum">1</span>); <span class="prismcomment">// protein degrades</span>
	[<span class="prismident">deactive</span>] <span class="prismident">a</span>&gt;<span class="prismnum">0</span> -&gt; <span class="prismident">a</span> : (<span class="prismident">a'</span>=<span class="prismident">a</span>-<span class="prismnum">1</span>); <span class="prismcomment">// deactivation (binds with repressor protein)</span>
	
<span class="prismkeyword">endmodule</span>

<span class="prismcomment">//--------------------------------------------------------</span>
<span class="prismcomment">// repressor modules</span>

<span class="prismcomment">// rename activator gene module</span>
<span class="prismkeyword">module</span> <span class="prismident">repressor_gene</span> = 
	<span class="prismident">activator_gene</span>[<span class="prismident">da</span>=<span class="prismident">dr</span>, <span class="prismident">da_a</span>=<span class="prismident">dr_a</span>, <span class="prismident">bind_a</span>=<span class="prismident">bind_r</span>, <span class="prismident">rel_a</span>=<span class="prismident">rel_r</span>, <span class="prismident">transc_da</span>=<span class="prismident">transc_dr</span>, <span class="prismident">transc_da_a</span>=<span class="prismident">transc_dr_a</span>]
<span class="prismkeyword">endmodule</span>

<span class="prismcomment">// rename activator mRNA module</span>
<span class="prismkeyword">module</span> <span class="prismident">repressor_mRNA</span> =
	<span class="prismident">activator_mRNA</span>[<span class="prismident">ma</span>=<span class="prismident">mr</span>, <span class="prismident">transl_a</span>=<span class="prismident">transl_r</span>, <span class="prismident">transc_da</span>=<span class="prismident">transc_dr</span>, <span class="prismident">transc_da_a</span>=<span class="prismident">transc_dr_a</span>, <span class="prismident">deg_ma</span>=<span class="prismident">deg_mr</span>]
<span class="prismkeyword">endmodule</span>

<span class="prismkeyword">module</span> <span class="prismident">repressor_protein</span>
	
	<span class="prismident">r</span>  : [<span class="prismnum">0</span>..<span class="prismident">N</span>]; <span class="prismcomment">// amount of repressor protein</span>
	
	[<span class="prismident">transl_r</span>] <span class="prismident">r</span>&lt;<span class="prismident">N</span> -&gt; (<span class="prismident">r'</span>=<span class="prismident">r</span>+<span class="prismnum">1</span>); <span class="prismcomment">// translation (mRNA to protein)</span>
	[<span class="prismident">deg_r</span>]   <span class="prismident">r</span>&gt;<span class="prismnum">0</span> -&gt;  <span class="prismident">r</span> : (<span class="prismident">r'</span>=<span class="prismident">r</span>-<span class="prismnum">1</span>); <span class="prismcomment">// protein degrades</span>
	[<span class="prismident">deactive</span>] <span class="prismident">r</span>&gt;<span class="prismnum">0</span> -&gt; <span class="prismident">r</span> : (<span class="prismident">r'</span>=<span class="prismident">r</span>-<span class="prismnum">1</span>); <span class="prismcomment">// deactivation of activator protein (protein binds with activator protein)</span>
	[<span class="prismident">deg_c</span>] <span class="prismident">r</span>&lt;<span class="prismident">N</span> -&gt; (<span class="prismident">r'</span>=<span class="prismident">r</span>+<span class="prismnum">1</span>); <span class="prismcomment">// activator protein degrades (when repressor protein is bound)</span>
	
<span class="prismkeyword">endmodule</span>

<span class="prismcomment">//--------------------------------------------------------</span>
<span class="prismcomment">// inactive protein module</span>

<span class="prismkeyword">module</span> <span class="prismident">inactive_protein</span>
	
	<span class="prismident">c</span> : [<span class="prismnum">0</span>..<span class="prismident">N</span>]; <span class="prismcomment">// amount of inactivated protein</span>
	
	[<span class="prismident">deactive</span>] <span class="prismident">c</span>&lt;<span class="prismident">N</span> -&gt; (<span class="prismident">c'</span>=<span class="prismident">c</span>+<span class="prismnum">1</span>); <span class="prismcomment">// protein forms (activator and repressor proteins bind)</span>
	[<span class="prismident">deg_c</span>] <span class="prismident">c</span>&gt;<span class="prismnum">0</span> -&gt; <span class="prismident">c</span> : (<span class="prismident">c'</span>=<span class="prismident">c</span>-<span class="prismnum">1</span>); <span class="prismcomment">// activator protein degrades</span>
	
<span class="prismkeyword">endmodule</span>

<span class="prismcomment">//--------------------------------------------------------</span>
<span class="prismcomment">// stochastic rates</span>

<span class="prismcomment">// add construct to give the fact that transcription is reduced</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">double</span> <span class="prismident">k</span>;

<span class="prismcomment">// rates module</span>
<span class="prismkeyword">module</span> <span class="prismident">rates</span>
	
	[<span class="prismident">transc_da</span>]   <span class="prismkeyword">true</span> -&gt; <span class="prismident">k</span>*<span class="prismnum">50</span>   : <span class="prismkeyword">true</span>; <span class="prismcomment">// transcription rate of activator gene</span>
	[<span class="prismident">transc_da_a</span>] <span class="prismkeyword">true</span> -&gt; <span class="prismident">k</span>*<span class="prismnum">500</span>  : <span class="prismkeyword">true</span>; <span class="prismcomment">// transcription rate of activator gene (activator protein bound)</span>
	[<span class="prismident">transc_dr</span>]   <span class="prismkeyword">true</span> -&gt; <span class="prismident">k</span>*<span class="prismnum">0.01</span> : <span class="prismkeyword">true</span>; <span class="prismcomment">// transcription rate of repressor gene</span>
	[<span class="prismident">transc_dr_a</span>] <span class="prismkeyword">true</span> -&gt; <span class="prismident">k</span>*<span class="prismnum">50</span>   : <span class="prismkeyword">true</span>; <span class="prismcomment">// transcription rate of repressor gene (activator protein bound)</span>
	[<span class="prismident">transl_a</span>]    <span class="prismkeyword">true</span> -&gt; <span class="prismnum">50</span>   : <span class="prismkeyword">true</span>; <span class="prismcomment">// translation rate of activator mRNA</span>
	[<span class="prismident">transl_r</span>]    <span class="prismkeyword">true</span> -&gt; <span class="prismnum">5</span>    : <span class="prismkeyword">true</span>; <span class="prismcomment">// translation rate of repressor mRNA</span>
	[<span class="prismident">bind_a</span>]      <span class="prismkeyword">true</span> -&gt; <span class="prismnum">1</span>    : <span class="prismkeyword">true</span>; <span class="prismcomment">// binding rate of activator gene and activator protein</span>
	[<span class="prismident">bind_r</span>]      <span class="prismkeyword">true</span> -&gt; <span class="prismnum">1</span>    : <span class="prismkeyword">true</span>; <span class="prismcomment">// binding rate of repressor gene and activator protein</span>
	[<span class="prismident">deactive</span>]    <span class="prismkeyword">true</span> -&gt; <span class="prismnum">2</span>    : <span class="prismkeyword">true</span>; <span class="prismcomment">// binding rate of activator and repressor proteins</span>
	[<span class="prismident">rel_a</span>]       <span class="prismkeyword">true</span> -&gt; <span class="prismnum">50</span>   : <span class="prismkeyword">true</span>; <span class="prismcomment">// release rate of activator gene and activator protein complex</span>
	[<span class="prismident">rel_r</span>]       <span class="prismkeyword">true</span> -&gt; <span class="prismnum">100</span>  : <span class="prismkeyword">true</span>; <span class="prismcomment">// release rate of repressor gene and activator protein complex</span>
	[<span class="prismident">deg_a</span>]       <span class="prismkeyword">true</span> -&gt; <span class="prismnum">1</span>    : <span class="prismkeyword">true</span>;  <span class="prismcomment">// degradation rate of activator protein</span>
	[<span class="prismident">deg_c</span>]       <span class="prismkeyword">true</span> -&gt; <span class="prismnum">1</span>	   : <span class="prismkeyword">true</span>; <span class="prismcomment">// degradation rate of activator protein</span>
	[<span class="prismident">deg_r</span>]       <span class="prismkeyword">true</span> -&gt; <span class="prismnum">0.2</span>  : <span class="prismkeyword">true</span>; <span class="prismcomment">// degradation rate of repressor protein</span>
	[<span class="prismident">deg_ma</span>]      <span class="prismkeyword">true</span> -&gt; <span class="prismnum">10</span>   : <span class="prismkeyword">true</span>; <span class="prismcomment">// degradation rate of activator mRNA</span>
	[<span class="prismident">deg_mr</span>]      <span class="prismkeyword">true</span> -&gt; <span class="prismnum">0.5</span>  : <span class="prismkeyword">true</span>; <span class="prismcomment">// degradation rate of repressor mRNA</span>
	
<span class="prismkeyword">endmodule</span>

<span class="prismcomment">//--------------------------------------------------------</span>
<span class="prismcomment">// reward structures</span>

<span class="prismkeyword">rewards</span> "<span class="prismident">activator_protein</span>" <span class="prismcomment">// amount of activator protein</span>
	<span class="prismkeyword">true</span> : <span class="prismident">a</span>;
<span class="prismkeyword">endrewards</span>

<span class="prismkeyword">rewards</span> "<span class="prismident">repressor_transcriptions</span>"
		[<span class="prismident">transc_dr</span>]   <span class="prismkeyword">true</span> : <span class="prismnum">1</span>;
	    [<span class="prismident">transc_dr_a</span>] <span class="prismkeyword">true</span> : <span class="prismnum">1</span>;
<span class="prismkeyword">endrewards</span>
</pre>
</body>
</html>
