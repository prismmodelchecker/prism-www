<span class="prismkeyword">const</span> <span class="prismkeyword">double</span> <span class="prismident">t</span>;

<span class="prismkeyword">R</span>{"<span class="prismident">a</span>"}=?[ <span class="prismkeyword">I</span>=<span class="prismident">t</span> ]
<span class="prismkeyword">R</span>{"<span class="prismident">r</span>"}=?[ <span class="prismkeyword">I</span>=<span class="prismident">t</span> ]
<span class="prismkeyword">R</span>{"<span class="prismident">activated</span>"}=?[ <span class="prismkeyword">C</span>&lt;=<span class="prismident">t</span> ]
