<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>
circadian.csl
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- Style sheet "prism.css" can be found in the "etc" directory of the PRISM distribution -->
<link type="text/css" rel="stylesheet" href="prism.css">
</head>
<body text="#000000" bgcolor="#ffffff">
<pre>
<span class="prismkeyword">const</span> <span class="prismkeyword">double</span> <span class="prismident">t</span>;

<span class="prismkeyword">R</span>{"<span class="prismident">a</span>"}=?[ <span class="prismkeyword">I</span>=<span class="prismident">t</span> ]
<span class="prismkeyword">R</span>{"<span class="prismident">r</span>"}=?[ <span class="prismkeyword">I</span>=<span class="prismident">t</span> ]
<span class="prismkeyword">R</span>{"<span class="prismident">activated</span>"}=?[ <span class="prismkeyword">C</span>&lt;=<span class="prismident">t</span> ]
</pre>
</body>
</html>
