<span class="prismcomment">// herman's self stabilising algorithm [Her90]</span>
<span class="prismcomment">// gxn/dxp 13/07/02</span>

<span class="prismcomment">// the procotol is synchronous with no nondeterminism (a DTMC)</span>
<span class="prismkeyword">dtmc</span>

<span class="prismcomment">// module for process 1</span>
<span class="prismkeyword">module</span> <span class="prismident">process1</span>

	<span class="prismident">x1</span> : [<span class="prismnum">0</span>..<span class="prismnum">1</span>] <span class="prismkeyword">init</span> <span class="prismnum">1</span>;
	
	[<span class="prismident">step</span>] (<span class="prismident">x1</span>=<span class="prismident">x7</span>) -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">x1'</span>=<span class="prismnum">0</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">x1'</span>=<span class="prismnum">1</span>);
	[<span class="prismident">step</span>] !(<span class="prismident">x1</span>=<span class="prismident">x7</span>) -&gt; (<span class="prismident">x1'</span>=<span class="prismident">x7</span>);
	
<span class="prismkeyword">endmodule</span>

<span class="prismcomment">// add further processes through renaming</span>
<span class="prismkeyword">module</span> <span class="prismident">process2</span> = <span class="prismident">process1</span>[<span class="prismident">x1</span>=<span class="prismident">x2</span>, <span class="prismident">x7</span>=<span class="prismident">x1</span> ] <span class="prismkeyword">endmodule</span>
<span class="prismkeyword">module</span> <span class="prismident">process3</span> = <span class="prismident">process1</span>[<span class="prismident">x1</span>=<span class="prismident">x3</span>, <span class="prismident">x7</span>=<span class="prismident">x2</span> ] <span class="prismkeyword">endmodule</span>
<span class="prismkeyword">module</span> <span class="prismident">process4</span> = <span class="prismident">process1</span>[<span class="prismident">x1</span>=<span class="prismident">x4</span>, <span class="prismident">x7</span>=<span class="prismident">x3</span> ] <span class="prismkeyword">endmodule</span>
<span class="prismkeyword">module</span> <span class="prismident">process5</span> = <span class="prismident">process1</span>[<span class="prismident">x1</span>=<span class="prismident">x5</span>, <span class="prismident">x7</span>=<span class="prismident">x4</span> ] <span class="prismkeyword">endmodule</span>
<span class="prismkeyword">module</span> <span class="prismident">process6</span> = <span class="prismident">process1</span>[<span class="prismident">x1</span>=<span class="prismident">x6</span>, <span class="prismident">x7</span>=<span class="prismident">x5</span> ] <span class="prismkeyword">endmodule</span>
<span class="prismkeyword">module</span> <span class="prismident">process7</span> = <span class="prismident">process1</span>[<span class="prismident">x1</span>=<span class="prismident">x7</span>, <span class="prismident">x7</span>=<span class="prismident">x6</span> ] <span class="prismkeyword">endmodule</span>

<span class="prismcomment">// formula, for use in properties: number of tokens</span>
<span class="prismcomment">// (i.e. number of processes that have the same value as the process to their left)</span>
<span class="prismkeyword">formula</span> <span class="prismident">num_tokens</span> = (<span class="prismident">x1</span>=<span class="prismident">x2</span>?<span class="prismnum">1</span>:<span class="prismnum">0</span>)+(<span class="prismident">x2</span>=<span class="prismident">x3</span>?<span class="prismnum">1</span>:<span class="prismnum">0</span>)+(<span class="prismident">x3</span>=<span class="prismident">x4</span>?<span class="prismnum">1</span>:<span class="prismnum">0</span>)+(<span class="prismident">x4</span>=<span class="prismident">x5</span>?<span class="prismnum">1</span>:<span class="prismnum">0</span>)+(<span class="prismident">x5</span>=<span class="prismident">x6</span>?<span class="prismnum">1</span>:<span class="prismnum">0</span>)+(<span class="prismident">x6</span>=<span class="prismident">x7</span>?<span class="prismnum">1</span>:<span class="prismnum">0</span>)+(<span class="prismident">x7</span>=<span class="prismident">x1</span>?<span class="prismnum">1</span>:<span class="prismnum">0</span>);

<span class="prismcomment">// rewards (to calculate expected number of steps)</span>
<span class="prismkeyword">rewards</span> "<span class="prismident">steps</span>"
	<span class="prismkeyword">true</span> : <span class="prismnum">1</span>;
<span class="prismkeyword">endrewards</span>
