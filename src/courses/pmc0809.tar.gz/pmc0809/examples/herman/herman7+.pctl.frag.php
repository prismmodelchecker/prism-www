<span class="prismcomment">// stable states - where only one process has the same value as the process to its left</span>
<span class="prismkeyword">label</span> "<span class="prismident">stable</span>" = <span class="prismident">num_tokens</span>=<span class="prismnum">1</span>;

<span class="prismcomment">// from the initial state, a stable state is reached with probability 1</span>
"<span class="prismkeyword">init</span>" =&gt; <span class="prismkeyword">P</span>&gt;=<span class="prismnum">1</span> [ <span class="prismkeyword">F</span> "<span class="prismident">stable</span>" ]

<span class="prismcomment">// from the initial state, what is the probability of</span>
<span class="prismcomment">// reaching a stable state within 10 steps</span>
<span class="prismkeyword">P</span>=? [ <span class="prismkeyword">F</span>&lt;=<span class="prismnum">10</span> "<span class="prismident">stable</span>" ]

<span class="prismcomment">// what is the expected number of steps required to reach a stable state?P=? [ true U&lt;=10 "stable" ]</span>
<span class="prismkeyword">R</span>=? [ <span class="prismkeyword">F</span> "<span class="prismident">stable</span>" ]
