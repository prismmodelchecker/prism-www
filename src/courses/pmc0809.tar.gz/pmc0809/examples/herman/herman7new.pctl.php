<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>
herman7new.pctl
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- Style sheet "prism.css" can be found in the "etc" directory of the PRISM distribution -->
<link type="text/css" rel="stylesheet" href="prism.css">
</head>
<body text="#000000" bgcolor="#ffffff">
<pre>
<span class="prismkeyword">const</span> <span class="prismkeyword">int</span> <span class="prismident">k</span>;

<span class="prismcomment">// states with k tokens</span>
<span class="prismkeyword">label</span> "<span class="prismident">k_tokens</span>" = <span class="prismident">num_tokens</span>=<span class="prismident">k</span>;

<span class="prismcomment">// stable states - where only one process has the same value as the process to its left</span>
<span class="prismkeyword">label</span> "<span class="prismident">stable</span>" = <span class="prismident">num_tokens</span>=<span class="prismnum">1</span>;

<span class="prismcomment">// maximum expected time to reach a stable state (for all k-token configurations)</span>
<span class="prismkeyword">R</span>=? [ <span class="prismkeyword">F</span> "<span class="prismident">stable</span>" {"<span class="prismident">k_tokens</span>"}{<span class="prismkeyword">max</span>} ]
</pre>
</body>
</html>
