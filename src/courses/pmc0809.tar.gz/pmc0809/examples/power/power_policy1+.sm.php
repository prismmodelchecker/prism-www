<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>
power_policy1+.sm
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- Style sheet "prism.css" can be found in the "etc" directory of the PRISM distribution -->
<link type="text/css" rel="stylesheet" href="prism.css">
</head>
<body text="#000000" bgcolor="#ffffff">
<pre>
<span class="prismcomment">// Simple dynamic power management (DPM) model</span>
<span class="prismcomment">// Based on:</span>
<span class="prismcomment">// Qinru Qiu, Qing Wu and Massoud Pedram</span>
<span class="prismcomment">// Stochastic modeling of a power-managed system: Construction and optimization</span>
<span class="prismcomment">// Proc. International Symposium on Low Power Electronics and Design, pages 194--199, ACM Press, 1999</span>

<span class="prismkeyword">ctmc</span>

<span class="prismcomment">//-----------------------------------------------------</span>

<span class="prismcomment">// Service Queue (SQ)</span>
<span class="prismcomment">// Stores requests which arrive into the system to be processed.</span>

<span class="prismcomment">// Maximum queue size</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">int</span> <span class="prismident">q_max</span> = <span class="prismnum">20</span>;

<span class="prismcomment">// Request arrival rate</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">double</span> <span class="prismident">rate_arrive</span> = <span class="prismnum">1</span>/<span class="prismnum">0.72</span>; <span class="prismcomment">// (mean inter-arrival time is 0.72 seconds)</span>

<span class="prismkeyword">module</span> <span class="prismident">SQ</span>
	
	<span class="prismcomment">// q = number of requests currently in queue</span>
	<span class="prismident">q</span> : [<span class="prismnum">0</span>..<span class="prismident">q_max</span>] <span class="prismkeyword">init</span> <span class="prismnum">0</span>;
	
	<span class="prismcomment">// A request arrives</span>
	[<span class="prismident">request</span>] <span class="prismkeyword">true</span> -&gt; <span class="prismident">rate_arrive</span> : (<span class="prismident">q'</span>=<span class="prismkeyword">min</span>(<span class="prismident">q</span>+<span class="prismnum">1</span>,<span class="prismident">q_max</span>));
	<span class="prismcomment">// A request is served</span>
	[<span class="prismident">serve</span>] <span class="prismident">q</span>&gt;<span class="prismnum">1</span> -&gt; (<span class="prismident">q'</span>=<span class="prismident">q</span>-<span class="prismnum">1</span>);
	<span class="prismcomment">// Last request is served</span>
	[<span class="prismident">serve_last</span>] <span class="prismident">q</span>=<span class="prismnum">1</span> -&gt; (<span class="prismident">q'</span>=<span class="prismident">q</span>-<span class="prismnum">1</span>);
	
<span class="prismkeyword">endmodule</span>

<span class="prismcomment">//-----------------------------------------------------</span>

<span class="prismcomment">// Service Provider (SP)</span>
<span class="prismcomment">// Processes requests from service queue.</span>
<span class="prismcomment">// The SP has 3 power states: sleep, idle and busy</span>

<span class="prismcomment">// Rate of service (average service time = 0.008s)</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">double</span> <span class="prismident">rate_serve</span> = <span class="prismnum">1</span>/<span class="prismnum">0.008</span>; 
<span class="prismcomment">// Rate of switching from sleep to idle (average transition time = 1.6s)</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">double</span> <span class="prismident">rate_s2i</span> = <span class="prismnum">1</span>/<span class="prismnum">1.6</span>;
<span class="prismcomment">// Rate of switching from idle to sleep (average transition time = 0.67s)</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">double</span> <span class="prismident">rate_i2s</span> = <span class="prismnum">1</span>/<span class="prismnum">0.67</span>;

<span class="prismkeyword">module</span> <span class="prismident">SP</span>
	
	<span class="prismcomment">// Power state of SP: 0=sleep, 1=idle, 2=busy</span>
	<span class="prismident">sp</span> : [<span class="prismnum">0</span>..<span class="prismnum">2</span>] <span class="prismkeyword">init</span> <span class="prismnum">0</span>;
	
	<span class="prismcomment">// Respond to controls from power manager (PM):</span>
	
	<span class="prismcomment">// Switch from sleep state to idle state</span>
	<span class="prismcomment">// (in fact, if the queue is non-empty, go straight to "busy" , rather than "idle")</span>
	[<span class="prismident">sleep2idle</span>] <span class="prismident">sp</span>=<span class="prismnum">0</span> &amp; <span class="prismident">q</span>=<span class="prismnum">0</span> -&gt; <span class="prismident">rate_s2i</span> : (<span class="prismident">sp'</span>=<span class="prismnum">1</span>);
	[<span class="prismident">sleep2idle</span>] <span class="prismident">sp</span>=<span class="prismnum">0</span> &amp; <span class="prismident">q</span>&gt;<span class="prismnum">0</span> -&gt; <span class="prismident">rate_s2i</span> : (<span class="prismident">sp'</span>=<span class="prismnum">2</span>);
	<span class="prismcomment">// Switch from idle state to sleep state</span>
	[<span class="prismident">idle2sleep</span>] <span class="prismident">sp</span>=<span class="prismnum">1</span> -&gt; <span class="prismident">rate_i2s</span> : (<span class="prismident">sp'</span>=<span class="prismnum">0</span>);
	
	<span class="prismcomment">// Synchronise with service queue (SQ):</span>
	
	<span class="prismcomment">// If in the idle state, switch to busy when a request arrives in the queue</span>
	[<span class="prismident">request</span>] <span class="prismident">sp</span>=<span class="prismnum">1</span>  -&gt; (<span class="prismident">sp'</span>=<span class="prismnum">2</span>);
	<span class="prismcomment">// If in other power states when a request arrives, do nothing</span>
	<span class="prismcomment">// (need to add this explicitly because otherwise SP blocks SQ from moving)</span>
	[<span class="prismident">request</span>] <span class="prismident">sp</span>!=<span class="prismnum">1</span> -&gt; (<span class="prismident">sp'</span>=<span class="prismident">sp</span>);
	
	<span class="prismcomment">// Serve a request from the queue</span>
	[<span class="prismident">serve</span>]      <span class="prismident">sp</span>=<span class="prismnum">2</span> -&gt; <span class="prismident">rate_serve</span> : (<span class="prismident">sp'</span>=<span class="prismnum">2</span>);
	[<span class="prismident">serve_last</span>] <span class="prismident">sp</span>=<span class="prismnum">2</span> -&gt; <span class="prismident">rate_serve</span> : (<span class="prismident">sp'</span>=<span class="prismnum">1</span>); 
	
<span class="prismkeyword">endmodule</span>

<span class="prismcomment">//-----------------------------------------------------</span>

<span class="prismcomment">// Power Manager (PM)</span>
<span class="prismcomment">// Controls power state of service provider</span>
<span class="prismcomment">// (this is done via synchronisation on idle2sleep/sleep2idle actions)</span>

<span class="prismcomment">// Bound on queue size, above which sleep2idle command is sent</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">int</span> <span class="prismident">q_trigger</span>;

<span class="prismkeyword">module</span> <span class="prismident">PM</span>
	
	<span class="prismcomment">// Send sleep2idle command to SP (when queue is of size q_trigger or greater)</span>
	[<span class="prismident">sleep2idle</span>] <span class="prismident">q</span>&gt;=<span class="prismident">q_trigger</span> -&gt; <span class="prismkeyword">true</span>;
	
	<span class="prismcomment">// Send idle2sleep command to SP (when queue is empty)</span>
	[<span class="prismident">idle2sleep</span>] <span class="prismident">q</span>=<span class="prismnum">0</span> -&gt; <span class="prismkeyword">true</span>;
	
<span class="prismkeyword">endmodule</span>

<span class="prismcomment">//-----------------------------------------------------</span>

<span class="prismcomment">// Reward structures</span>

<span class="prismkeyword">rewards</span> "<span class="prismident">queue_size</span>"
	<span class="prismkeyword">true</span> : <span class="prismident">q</span>;
<span class="prismkeyword">endrewards</span>

<span class="prismkeyword">rewards</span> "<span class="prismident">lost</span>"
	[<span class="prismident">request</span>] <span class="prismident">q</span>=<span class="prismident">q_max</span> : <span class="prismnum">1</span>;
<span class="prismkeyword">endrewards</span>

<span class="prismkeyword">rewards</span> "<span class="prismident">power</span>"
	<span class="prismident">sp</span>=<span class="prismnum">0</span> : <span class="prismnum">0.13</span>;
	<span class="prismident">sp</span>=<span class="prismnum">1</span> : <span class="prismnum">0.95</span>;
	<span class="prismident">sp</span>=<span class="prismnum">2</span> : <span class="prismnum">2.15</span>;
	[<span class="prismident">sleep2idle</span>] <span class="prismkeyword">true</span> : <span class="prismnum">7</span>;
	[<span class="prismident">idle2sleep</span>] <span class="prismkeyword">true</span> : <span class="prismnum">0.067</span>;
<span class="prismkeyword">endrewards</span>
</pre>
</body>
</html>
