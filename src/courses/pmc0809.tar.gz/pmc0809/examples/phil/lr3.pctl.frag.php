<span class="prismcomment">// deadlock freeness</span>
"<span class="prismident">hungry</span>" =&gt; <span class="prismkeyword">P</span>&gt;=<span class="prismnum">1</span> [ <span class="prismkeyword">F</span> "<span class="prismident">eat</span>"]

<span class="prismcomment">// no resource starvation</span>
"<span class="prismident">hungry1</span>" =&gt; <span class="prismkeyword">P</span>&gt;=<span class="prismnum">1</span> [ <span class="prismkeyword">F</span> "<span class="prismident">eat1</span>"]
"<span class="prismident">hungry2</span>" =&gt; <span class="prismkeyword">P</span>&gt;=<span class="prismnum">1</span> [ <span class="prismkeyword">F</span> "<span class="prismident">eat2</span>"]
"<span class="prismident">hungry3</span>" =&gt; <span class="prismkeyword">P</span>&gt;=<span class="prismnum">1</span> [ <span class="prismkeyword">F</span> "<span class="prismident">eat3</span>"]
