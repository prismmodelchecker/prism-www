<?php $title = "Probabilistic Model Checking - Practicals"; $nav = "doc"; require '../../includes/header.php'; ?>

<!-- ============================================================================ -->

<h1><a href="index.php">Probabilistic Model Checking Practicals</a></h1>

<h3>Installing PRISM on your own machine</h3>

<hr>

<p>
For the reasons outlined above, it is recommended to install the latest development
version of PRISM, rather than the public release available on the website.
PRISM runs on Windows, Linux, Mac etc. and should be relatively straightforward to install.
The main pre-requisite is that you have Sun's 
<a href="http://java.sun.com/javase/downloads/">Java</a> installed.
Distributions of PRISM are available here:
</p>
<ul>
<li><a href="prism-3.2.r808-win-installer.exe">Windows</a>
<li><a href="prism-3.2.r808-linux.tar.gz">Linux</a>
<li><a href="prism-3.2.r808-src.tar.gz">Source code</a>
</ul>
<p>
and <a href="/manual/InstallingPRISM/Instructions">installation instructions</a>
can be found in the <a href="/manual/">PRISM manual</a> (which is also distributed with the tool).
</p>

<p>
For Windows, there is self-extracting installer.
For Mac, you need to build PRISM from the source code
(as described in the <a href="/manual/InstallingPRISM/Instructions">instructions</a>).
For Linux, you will probably be able to use the binary version above;
if not, you can also build PRISM from the source code version.
</p>

<p>
If you have any difficulties, you can check the list of
<a href="/manual/InstallingPRISM/CommonProblemsAndQuestions">common problems and questions</a>.
Otherwise, please contact
<a href="http://web.comlab.ox.ac.uk/people/Gethin.Norman/index.html">Gethin Norman</a>
or <a href="http://web.comlab.ox.ac.uk/people/David.Parker/index.html">Dave Parker</a>.
</p>

<hr>

<br><br><br><br><br><br><br><br><br>

<!-------------------------------------------------------------------------------->

<?php require '../../includes/footer.php'; ?>
