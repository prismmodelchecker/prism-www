<?php $title = "Probabilistic Model Checking - Practicals - Practical 1"; $nav = "doc"; require '../../includes/header.php'; ?>

<!-- ============================================================================ -->

<h1><a href="index.php">Probabilistic Model Checking Practicals</a></h1>

<h3>Practical 1</h3>

<p>
This practical introduces the basics of the PRISM modelling language and the PRISM tool. 
</p>

<p>
Items that should be included in your practical report are
marked with a <b>[*]</b> below
(and also summarised at the end of this page).
</p>

<!-- ============================================================================ -->

<div class="prism-rule"></div>

<h3>1. The die example</h3>

<p>
Our first example is a PRISM model of a simple probabilistic algorithm due to
Knuth and Yao <?php prism_cite("KY76"); ?> for emulating a 6-sided die with a fair coin.
You should remember this example from the lectures.
Here is a graphical illustration of the algorithm:
</p>

<img class="prism-image" src="images/dice.pic.gif" alt="Die algorithm">

<p>
The idea of the algorithm is as follows.
Starting from step 0 (i.e. the circle labelled 0),
at every step a coin is tossed and there is 50% chance
of taking each of the two possible choices.
The algorithm terminates when you reach one of the values for the die on the right-hand side.
</p>

<p>
The PRISM code to model this algorithm is shown below.
</p>

<?php prism_code("die/die.pm") ?>

<p>
The first line indicates that this model is a discrete-time Markov chain (DTMC).
The remaining lines describe a single PRISM module,
which we use to model the behaviour of the algorithm.
We use two variables to represent the state of the system:
<span class="prismident">s</span>,
denoting which step of the algorithm is currently being executed
(i.e. which circle in the diagram above),
and <span class="prismident">d</span>,
denoting the value of the die (0 means no value has been chosen yet).
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Read the sections on
<a href="/manual/ThePRISMLanguage/ModulesAndVariables">modules/variables</a> and
<a href="/manual/ThePRISMLanguage/Commands">commands</a>
in the manual and try to understand how this description represents the algorithm.
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>2. Exploring the model in PRISM</h3>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Download the model file <b>die.pm</b> for this example from the link above.
Launch the <a href="/manual/RunningPRISM/StartingPRISM">PRISM GUI</a>
and load this file using the "Model | Open model" menu option.
You should see a green tick in the top left corner indicating that the model was loaded successfully.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Click on the "Simulator" tab in the GUI.
You can now use the
<a href="/manual/RunningPRISM/DebuggingModelsWithTheSimulator">simulator</a>
to explore the model.
Create a new path by double-clicking on the main part of the window
(or right-clicking and selecting "New path")
and accept the choice of initial state provided by clicking "OK".
Then, use the "Simulate" button repeatedly to generate a sample execution of the algorithm.
Look at the trace displayed in the main part of the window.
What is the final value of <span class="prismident">s</span>?
It should be 7. What is the value of the die?
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Right-click and select "Reset path".
Then, step through a trace of the algorithm manually
by double-clicking the available transitions
from the "Manual exploration" box.
Try to reach a state where the value of the die is 6.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Now change the value of the "Steps" option under the "Simulate" button from 1 to 20
and, using the "Reset path" option and "Simulate" buttons,
generate several different random traces.
What is the minimum path length you observe? What is the maximum?
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>3. Model checking with PRISM</h3>

<p>
We will now use PRISM to perform some analysis of the model.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Download the properties file <b>die.pctl</b> below and then
load it into PRISM using the "Properties | Open properties list" menu option.
</p>

<?php prism_code("die/die.pctl") ?>

<p>
The file comprises a constant <span class="prismident">x</span>,
whose value we leave undefined, and one property.
The property is of the form
<span class="prismkeyword">P</span>=? [ <span class="prismkeyword">F</span> <span class="prismident">phi</span> ]
which, intuitively, means
"what is the probability, from the initial state of the model,
of reaching a state where <span class="prismident">phi</span> is true?"
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
What does <span class="prismident">phi</span> mean in this case?
What does the property mean?
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Right click on the property in the GUI and select "Verify".
Pick a value of <span class="prismident">x</span> between 1 and 6.
Is the answer as you expected?
Click on the "Log" tab to see some additional information that PRISM has displayed regarding the calculations performed.
</p>

PRISM uses iterative numerical solution techniques which converge towards the precise result.
The numerical computation process is terminated when it is detected that the answers have converged sufficiently.
Have a look at the
<a href="/manual/ConfiguringPRISM/IterativeNumericalMethods">manual</a>
for more information.

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Open the PRISM options panel from the menu.
Find the "Termination epsilon" parameter and change it from 1.0e-6 to 1.0e-10.
Re-verify the property and see how the answer changes.
Check the log again and see many more iterations were required.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Reset the "Termination epsilon" parameter to 1.0e-6.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Read the section in the PRISM manual describing
<a href="/manual/RunningPRISM/Experiments">experiments</a>.
Use PRISM to plot a graph of the value of the property 
<span class="prismkeyword">P</span>=? [ <span class="prismkeyword">F</span> <span class="prismident">phi</span> ]
for values of <span class="prismident">x</span> between 0 and 7.
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>4. Aproximate model checking with PRISM</h3>

<p>
PRISM also has a discrete-event simulation engine which can be used to generate
<a href="/manual/RunningPRISM/ApproximateComputationOfQuantitativeProperties">approximate</a> verification results.
This engine is also what underlies the simulator that you used earlier to explore the model manually.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Re-run your experiment using the simulator by ticking the "Use Simulation" option in the experiment dialog.
On the "New Graph Series" dialog, choose to display the results on your existing graph.
In the next dialog, which shows parameters for the simulation process,
you will see that the default number of samples is set to 412042.
Change the number of samples to 10
(if the field is not editable, select a different option from the 
"Automatically Calculate" drop-down menu).
How are good are these approximate results?
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Keep re-running the experiment, plotting the results on the same graph each time,
and changing the number of samples to 100, 1000, etc.
How many samples do you need to get results close to those generated through verification?
</p>

<p>
If you want to change the legend or other propeties of the graph,
right-click and select "Graph options".
You can also export or print the graph from this menu.
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>5. Expected termination time</h3>

<p>
We will now use PRISM to compute the expected number of steps that
the algorithm being modelled requires to generate a value for the die.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Before you do this, can you compute the result by hand?
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
You need to add some <b>costs</b> to the model.
In PRISM, we use the terminology "reward", rather than "cost". The two are synonomous.
Go to the "Model" tab of the PRISM GUI and add the following code to the end of the model.
</p>

<pre class="prism-code">
<span class="prismkeyword">rewards</span> "<span class="prismident">steps</span>"
	<span class="prismkeyword">true</span> : <span class="prismnum">1</span>;
<span class="prismkeyword">endrewards</span>
</pre>

<p>
This associates a reward of 1 with every state in the model.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Go back to the simulator and generate a random path through the model.
You will see that the reward for each state is now displayed in the table.
Right-click on the path, choose "Configure view" and, from the "Reward visibility" tab,
add the item labelled "cumulative" to the list of visible items
by selecting it from the right-hand panel an clicking the left arrow.
Create another path in the simulator and you will see that the accumulation
of rewards along a path are now also displayed.

</p>

<p>
We will now use PRISM to compute the expected number of steps.
This can be done with a property of the form:
</p>

<pre class="prism-code">
<span class="prismkeyword">R</span>=? [ <span class="prismkeyword">F</span> <span class="prismident">phi</span> ]
</pre>

<p>
which means "what is the expected value of the rewards cumulated, from the initial state of the model,
until we reach a state satisfying <span class="prismident">phi</span>?''.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
What should <span class="prismident">phi</span> be in order to compute
the expected number of steps that the algorithm requries to compute a value for the die?
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Go to the "Properties" tab and add this new property to the list of properties.
Verify the property.
Note that you will be prompted for a value of <span class="prismident">x</span>,
which is not used here so it does not matter what value you specify.
What is the result?
The precise answer is 11/3.
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>6. Herman's self-stabilisation algorithm</h3>

<p>
We now consider a second example:
a self-stabilisation algorithm due to Herman.
A self-stabilisation algorithm for a network of processes
is a protocol which, when started from some possibly "illegal" start state,
returns to a "legal" state without any outside intervention and within some finite number of steps.
We call a "legal" state a <b>stable</b> state.
</p>

<p>
Here is a PRISM model of Herman's algorithm for 7 processes:
</p>

<?php prism_code("herman/herman7.pm") ?>

<p>
The processes are arranged in a ring and are identical.
Notice how we use PRISM's
<a href="/manual/ThePRISMLanguage/ModuleRenaming">module renaming</a>
facility to avoid duplicating the module definition for each process.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Have a look at the code and work out what a process does at each step of the protocol.
Notice the <span class="prismident">step</span> action in the square brackets at the start of every command.
This is used to force all 7 processes to synchronise (move simultaneously at each step).
You can read more about synchronisation in the
<a href="/manual/ThePRISMLanguage/Synchronisation">manual</a>.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Download the model file <b>herman7.pm</b> from above and load it into PRISM.
</p>

<p>
The state of each process is given by a single 0/1-valued variable.
Initially, this value is 1 for all processes
(note how this is done in the variable definition in the model file).
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
What is the maximum possible number of states that this model can be in?
Are all of these states reachable from the initial configuration (1,1,1,1,1,1,1) of the model?
Select the "Model | Build model" menu option
and look at the information displayed in the bottom left of the GUI to find out.
Take a look at the log to see additional information displayed about the model building process.
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>7. Reaching a stable state</h3>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Download the property file below and load it into PRISM:
</p>

<?php prism_code("herman/herman7.pctl") ?>

<p>
For this self-stabilisation algorithm, a stable state is defined as one
in which only a single process has a token.
A process is said to possess a token if its variable is the same as the process to its left.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Look at the label "<span class="prismident">stable</span>" which is defined in the file above
and the formula <span class="prismident">num_tokens</span> from the model file which it uses.
Check that you understand how it relates to the definition of a stable state.
Look at the <a href="/manual/ThePRISMLanguage/Expressions">expressions</a>
section of the manual if not.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Use the PRISM simulator to generate some random paths through the model.
Click on the "<span class="prismident">stable</span>" label in the top-right part of the simulator
to help you identify which states of these paths are stable.
Note that in this model of the algorithm, we do not actually terminate when a stable state has been reached.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
We would like to know whether, from the initial state, a stable state is eventually reached with probability 1.
Check this by verifying the property included in the <b>herman7.pctl</b> file that you loaded into PRISM
(do not forget to deselect the "Use Simulation" option if it is still selected).
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
If you used a non-probabilistic model checker to verify whether
"from the initial state, a stable state is <b>always</b> eventually reached", what would the result be?
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Read about the P Operator in the PRISM manual
(<a href="/manual/PropertySpecification/ThePOperator">here</a>
and <a href="/manual/PropertySpecification/QuantitativeProperties">here</a>).
Modify the existing property (double-click or right-click and "Edit") to see if
"the probability of a stable state being reached within 10 steps is (greater than or equal to) 1".
Is it greater than 0.5?
What is the actual probability?
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Notice that, like in the die example,
we have assigned a reward of 1 to each state of the model.
Create and verify a new property to answer the question
"what is the expected number of steps required for the self-stabilisation algorithm to reach a stable state?".
<!-- The result should be (approximately) 5.4933. -->
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>8. Initial configurations</h3>

<p>
So far, all our analysis has been for a fixed initial state of the model.
We will now carry out a more exhaustive examination of the protocol by considering different classes of initial configuration.
PRISM allows a model to have more than one initial state.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Modify the model by removing the "<span class="prismkeyword">init</span> <span class="prismnum">1</span>"
part of the definition for variable <span class="prismident">x1</span>
(and thus also for <span class="prismident">x2</span>, <span class="prismident">x3</span>, ... ,<span class="prismident">x7</span>
since they are defined by renaming).
Add the following code to the end of the model:
</p>

<pre class="prism-code">
<span class="prismkeyword">init</span>
	<span class="prismkeyword">true</span>
<span class="prismkeyword">endinit</span>
</pre>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Check that the model still builds without errors ("Model | Build model").
</p>

<p>
Any possible configuration of the process is now considered as an initial state of the model.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Download the following modified properties file and load it into PRISM:
</p>

<?php prism_code("herman/herman7new.pctl") ?>

<p>
This property allows us to compute
"the maximum expected time to reach a stable state, starting from any initial configuration in which there are k tokens".
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Verify this property for <span class="prismident">k</span>=7.
Do you get the same value as earlier?
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Create an experiment to compute and plot a graph of the values of the property
for all <b>odd</b> values of <span class="prismident">k</span> between 1 
and 
7.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Look in the log. You can see exactly which of the various possible configurations result in these worst-case answers.
<b>[*]</b>
<br><br>
[Note: in cases where there are more than 10 such configurations, PRISM just prints the first 10.
This is all that you need to include in your submission for this practical.]
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
There are no possible initial configurations with even numbers of tokens. Why?
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
For which value of <span class="prismident">k</span> is the expected time lowest? Why?
For which value is it highest?
<!-- Look at the <a href="/casestudies/self-stabilisation.php">page</a> for this example
in the case studies section of the PRISM web site if you want to find out more about this. -->
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Create another PRISM property which computes the <b>minimum</b> expected time to reach a stable state,
starting from any initial configurations in which there are <span class="prismident">k</span> tokens.
Plot this value for <span class="prismident">k</span>=1,3,5,7 on a single graph. <b>[*]</b>
</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>Practical Report</h3>

<p>
To get this practical signed off,
you should provide the demonstrator with a brief practical report
comprising the starred items from the text above, i.e.:
<ol>
<li> from part 8: a list of configurations (for each value of k=1,3,5,7) resulting in maximum expected time;
<li> from part 8: the PRISM property for minimum expected time and the corresponding graph.
</ol>

</p>

<!-- ============================================================================ -->
<div class="prism-rule"></div>

<p>
[ <a href="index.php">Back to index</a> ]
</p>

<!-------------------------------------------------------------------------------->


<!-------------------------------------------------------------------------------->

<?php require '../../includes/footer.php'; ?>
