<?php $title = "Probabilistic Model Checking - Practicals"; $nav = "doc"; require '../../includes/header.php'; ?>

<!-- ============================================================================ -->

<h1><a href="index.php">Probabilistic Model Checking Practicals</a></h1>

<h3>Michaelmas Term 2009</h3>

<hr>

<p>
These practical exercises are based on the
<a href="http://www.prismmodelchecker.org/">PRISM</a> tool.
This is already installed (under Linux) on the lab machines in room 379.
However, you will be expected to complete some of this work outside of the lab sessions.
You will also require PRISM to complete the take-home assignment at the end of the course.
Therefore, you will mostly likely wish to install a copy of PRISM on your own machine.
Please see either
<a href="http://www.comlab.ox.ac.uk/people/David.Parker/">Dave Parker</a>
or <a href="http://www.comlab.ox.ac.uk/people/Hristina.Palikareva/">Hristina Palikareva</a>
as soon as possible 
if you have any problems in this respect.
</p>

<p>
<b>Running PRISM in room 379:</b><br>
PRISM is installed under Linux on these machines.
You can run it by just typing <tt>xprism</tt> at the command line.
</p>

<p>
<b>Installing PRISM on your own machine:</b><br>
See <a href="prism.php">here</a>.

<hr>

<h3>Resources</h3>

<p>
The best source of information about PRISM is the online <a href="/manual/">manual</a>.
</p>

<p>
Outside of the lab sessions,
general questions about PRISM (but not specifically about the exercises, please)
can be sent to the
<a href="http://groups.google.com/group/prismmodelchecker">PRISM discussion group</a>.
</p>

<hr>

<h3>The Practicals</h3>

<!--<p>Links to each of the 4 practical exercises will appear here:</p>-->

<ul>
<!--<li> <a href="practical1.php">Practical 1</a>-->
<li> <a href="practical1.php">Practical 1</a>
<li> <a href="practical2.php">Practical 2</a>
<li> <a href="practical3.php">Practical 3</a>
<li> <a href="practical4.php">Practical 4</a>
</ul>

<hr>

<br><br><br><br><br><br><br><br><br>

<!-------------------------------------------------------------------------------->

<?php require '../../includes/footer.php'; ?>
