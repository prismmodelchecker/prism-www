<?php $title = "Probabilistic Model Checking - Practicals - Practical 4"; $nav = "doc"; $nav2 = "tutorial"; require '../../includes/header.php'; ?>

<!-- ============================================================================ -->

<h1><a href="index.php">Probabilistic Model Checking Practicals</a></h1>

<h3>Practical 4</h3>

<p>
This practical concerns using the PRISM tool for the specification and analysis of Markov decision process models. 
</p>

<p>
Items that should be included in your practical report are
marked with a <b>[*]</b> below
(and also summarised at the end of this page).
</p>

<!-- ============================================================================ -->

<div class="prism-rule"></div>

<h3>1. The Dining philosophers problem</h3>

<p>
The dining philosophers problem is an example of a large class
of concurrency problems that attempt to deal with allocating a set number of resources among several processes. 
The problem originates with Edsger Dijkstra, who in  1971  set an examination question where five computers
competed for access to five shared tape drives. The problem was then retold by Tony Hoare as the
dining philosophers problem.
</p>

<p>
The problem supposes a certain number of philosophers, seated around a circular table, spend their lives alternating between thinking and eating. 
There is a fork placed between each pair of neighbouring philosophers which both can access and
a philosopher must be in possession of both forks in order to eat.
A philosopher may only pick up one fork at a time
and when a philosopher finishes eating, both forks are placed back on the table and he/she returns to thinking.
Notice that, since the philosophers share forks, it is not possible for all to eat at the same time.
<p>

<p>
Below we represent graphically the case when there are five philosophers seated around the table.
</p>

<img class="prism-image" src="images/dining-phil.png" alt="image of dining philosophers" width="40%">

<p>
A solution to this problem is an algorithm for each of the philosophers to follow that
will ensure that:
</p>

<ul>
<li> there will never be a situation of <em>deadlock</em> (i.e. where no philosopher gets to eat)
<li> there will never be a situation of <em>resource starvation</em> (i.e. where a philosopher wants to eat but never does so).
</ul>

<p>
For an example of a situation that can lead to deadlock, suppose that all philosophers become hungry
at the same time and reach out and take their left fork, then if
all reach for the right fork no one can move.
</p>

<!-- ============================================================================ -->

<div class="prism-rule"></div>

<h3>2. A Randomised Solution</h3>

We now consider  Lehmann and Rabin's <?php prism_cite("LR81"); ?> randomised
solution which ensures that the system is deadlock-free,
more precisely that, if a philosopher is hungry, then eventually a philosopher eats.
</p>

<p>
The PRISM model in the case of three philosophers is given below.
</p>

<?php prism_code("phil/lr3.nm") ?>

<p>
This model is a Markov decision process (MDP),
as denoted by the keyword at the start of the file.
We have three modules, representing the three philosophers.
</p>

<p>
Notice that, after a philosopher eats
(e.g. when <span class="prismident">p1</span>=<span class="prismnum">9</span> for philosopher 1),
the nondeterministic choice as to which fork he/she puts down first is represented by two commands being enabled
(i.e. there are multiple commands with overlapping guard <span class="prismident">p1</span>=<span class="prismnum">9</span>).
</p>

<p>
Notice also the use of the PRISM
<a href="/manual/ThePRISMLanguage/FormulasAndLabels">formulae</a>
(<span class="prismident">lfree</span> and <span class="prismident">rfree</span>)
to represent expressions that are re-used several times in the file.
In this model, these formulae are used to identify states of the left (or right)
neighbour of a philosopher in which he/she is not using his/her fork.
As a consequence, this requires the renaming of
each of the variables <span class="prismident">p1</span>, <span class="prismident">p2</span> and 
<span class="prismident">p3</span> when constructing the modules for philosophers 2 and 3. This renaming
corresponds to the fact that the left and right neighbours of philosopher 2 and 3 differ from that of philosopher 1.
</p>

<p>
The basics steps of the algorithm for each philosopher are:
</p>

<ol>
<li> move from thinking to hungry (to simplify the analysis we assume that philosophers always become hungry);
<li> when hungry, randomly choose to try and pick up the left or right fork;
<li> wait until the fork is down and then pick it up;
<li> if the other fork is free, pick it up;
otherwise, put the original fork down (and return to step 1);
<li> eat (since in possession of both forks);
<li> when finished eating, put both forks down in any order and return to thinking.
</ol>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Download the model file <b>lr3.nm</b> from above and load it into PRISM.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Before starting you should modify one of the settings in PRISM: launch the "Options" dialog from the main menu
and set the "engine" to be "MTBDD" (this might already be the case if you saved your setting in a previous practical).
This is because not all the model checking algorithms used in the practical are currently supported by the other engines.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Use the PRISM simulator to generate some random paths through the model.
Notice how, for a MDP model like this, multiple probability distributions may be available in a state.
Generate a path by hand where one of the philosophers eats.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
By using module renaming write versions of the algorithm when there are 4 and 5 philosophers. 
One thing to take into account is whether the neighbours of the philosophers change. <b>[*]</b>
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
For each of the models, add labels corresponding to whether each individual philosopher is hungry/eating.
</p>

<!-- ============================================================================ -->

<div class="prism-rule"></div>

<h3>3. Analysing Lehmann and Rabin's Solution</h3>

<p>
We will now use PRISM to analyse the above model.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Load the following properties file into PRISM:
</p>

<?php prism_code("phil/lr3.pctl") ?>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Check that the model is deadlock-free, but is not resource starvation-free.
Also verify your models for four and five philosophers against these specifications.</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Read the section of the manual on
<a href="/manual/PropertySpecification/QuantitativeProperties">Quantitative Properties</a>
and, in particular the parts concerning filters, as we will uses these in our specifications.
</p>


<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Construct properties to compute, from the state where <em>all</em> philosophers are thinking,
both the minimum and maximum probability that a philosopher eats within k steps and plot
results for the case of three, four and five philosophers.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Construct reward structures and properties to find both the minimum and maximum expected time for a philosopher to eat from the state where <em>all</em> philosophers are thinking. Verify these properties on the models of three and four philosophers. Describe a strategy that achieves the minimum expected time. <b>[*]</b>
</p>

<!-- ============================================================================ -->

<div class="prism-rule"></div>

<h3>4. A Resource Starvation-Free Solution</h3>

<p>
Lehmann and Rabin solved the resource-starvation problem by
extending the above approach so that the philosophers are courteous.
More precisely: 
a philosopher will not pick up his/her neighbour’s fork (when it has no forks) if that neighbour
is trying to eat and has not eaten since the philosopher's most recent meal.
</p>

<p>
This is achieved by using shared variables between neighbouring
philosophers and shown by the following pseudo-code.
</p>

<table class="prism-table"><tr><td><br/>
<b>var</b> <span class="prismident">Ieft-signal</span>, <span class="prismident">right-signal</span> : 
{<span class="prismnum">On</span>,<span class="prismnum">Off</span>};<br/>
***<em> <span class="prismident">Ieft-signal</span> is shared with left neighbour initially set to <span class="prismnum">Off</span>  </em>***<br/>
***<em> It is set to <span class="prismnum">On</span> when one becomes hungry and restored to <span class="prismnum">Off</span> only after eating. </em>***<br/>
***<em> The left neighbour may read it but not  change it and refers to it as <span class="prismident">right-neighbour-signal</span> . </em>***<br/>
***<em> The case is symmetric for the <span class="prismident">right-signal</span>. </em>***<br/><br/>
<b>read only var</b> <span class="prismident">left-neighbour-signal</span> ,<span class="prismident">right-neighbour-signal</span> : {<span class="prismnum">On</span>,<span class="prismnum">Off</span>};<br/>
***<em> left-neighbour-signal is left neighbour’s  right signal. </em>*** <br/><br/>
<b>var</b> <span class="prismident">left-last</span>,<span class="prismident">right-last</span> :
{<span class="prismnum">Left</span>,<span class="prismnum">Neutral</span>,<span class="prismnum">Right</span>};<br/>
***<em> <span class="prismident">left-last</span> is shared with left neighbour and both may change it. </em>***<br/>
***<em> It indicates who ate last : left from fork or right from fork </em>***<br/>
***<em> Initially the value is Neutral (as no one has eaten) </em>***<br/>
***<em> <span class="prismident">left-last</span> is the same as left neighbour’s  <span class="prismident">right-last</span>. </em>***<br/><br/>
1.  <span class="prismident">trying</span>:=<b>true</b> ***<em> move from thinking to hungry </em>***<br/>
2.&nbsp;&nbsp;  <span class="prismident">left-signal</span>:=<span class="prismnum">On</span>; <span class="prismident">right-signal</span>:=<span class="prismnum">On</span>
3.&nbsp;&nbsp; <b>while</b> <span class="prismident">trying</span> <b>do</b><br/> 
4.&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;	‘draw a random element <span class="prismnum">s</span> of {<span class="prismnum">Right</span>,<span class="prismnum">Left</span>}; ***<em> with equal probabilities </em>***<br/>
5.&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;	<b>wait until</b> <span class="prismnum">s</span> fork is down and (<span class="prismident">s-neighbour-signal</span>=<span class="prismnum">Off</span>  or <span class="prismident">s-last</span>=<span class="prismnum">Neutral</span> or <span class="prismident">s-last</span>=<span class="prismnum">s</span>)<br/>
6.&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;	<b>then</b> lift fork <span class="prismnum">s</span><br/>
7.&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;	<b>if</b> R(<span class="prismnum">s</span>) fork is down ***<em> R(<span class="prismnum">Right</span>)=
<span class="prismnum">Left</span> and R(<span class="prismnum">left</span>)=<span class="prismnum">Right</span> </em>***<br/>
8.&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;	 <b>then</b> lift it and <span class="prismident">trying</span>:=<b>false</b><br/>
9.&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;	 <b>else</b> put down fork <span class="prismnum">s</span><br/>
10.&nbsp;&nbsp;  <b>od</b><br/>
11.&nbsp;&nbsp; eat;<br/>
12.&nbsp;&nbsp; <span class="prismident">left-signal</span>:=<span class="prismnum">Off</span>; <span class="prismident">right-signal</span>:=<span class="prismnum">Off</span>;<br/>
13.&nbsp;&nbsp; <span class="prismident">left-last</span>:=<span class="prismnum">Right</span>; <span class="prismident">right-last</span>:=<span class="prismnum">Left</span>;<br/>
14.&nbsp;&nbsp; put down both forks ***<em> one at a time in any order </em>***<br/><br/>
</table>

<p>
We will now extend our PRISM code to specify Lehmann and Rabin's courteous dining philosophers.

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
First, save a new copy of the model <tt>lr3.nm</tt> as <tt>clr3.pm.</tt>
</p>
<p>

Next, we will add a number of constants, variables and formulae that will be needed in the specification.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Add constants for <span class="prismident">NEUTRAL</span>,
<span class="prismident">LEFT</span> and <span class="prismident">RIGHT</span> which take the values 0, 1 and 2 respectively.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
To represent the variables left-signal and right-signal,
add the variables <span class="prismident">left_signal1</span> and <span class="prismident">right_signal1</span> 
to philosopher 1 and add similar variables for philosophers 2 and 3 through renaming.
Define a suitable ranges and initial values for these variables given that left-signal and right-signal take two values (Off and On).
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
In the pseudo code there are two shared variables, left-last and right-last,
that we will represent in PRISM using global variables.
Read the sections on
<a href="/manual/ThePRISMLanguage/GlobalVariables">global variables</a>
in the manual.
Now add global variables <span class="prismident">fork1_last</span>, <span class="prismident">fork2_last</span> and <span class="prismident">fork3_last</span> which
will be used to represent the variables left-last and right-last in
the pseudo code above. 
Define suitable ranges and initial values for these variables given that these variables take the values NEUTRAL, LEFT and RIGHT
(and the constants we introduced above).
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Draw a diagram
of the three philosophers (phil1, phil2 and phil3) and three forks (fork1, fork2 and fork3) 
as this will help understand the relationships between the philosophers and the forks.
For example, this should make to easier to work out
which fork/philosopher is to the right/left of philosopher 1.
</p>


<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Write formulae for philosopher 1 being courteous when waiting
to pick up his/her left fork and when waiting to pick up his/her right fork.
Now rename the appropriate variables in the modules of philosopher 2 and 3 such that after
renaming these formulae they correctly model these philosophers being courteous.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Using the above constants, variables and formulae modify the commands of <span class="prismident">phil1</span> to match the pseudo
code for the courteous dining philosophers defined above. Note that you will probably have to extend the range of
<span class="prismident">p1</span> and you will also have to change the labels at the end of the file to match
your modifications. Notice since you have already changed the renaming to match the new variables
and formulae the modules <span class="prismident">phil2</span> and <span class="prismident">phil3</span> should
also now correctly model the courteous dining philosophers. <b>[*]</b>
</p>

<!-- ============================================================================ -->

<div class="prism-rule"></div>

<h3>5. Analysing the Courteous Philosophers</h3>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
Check the protocol is resource starvation-free and deadlock-free.
</p>

<p><img class="prism-task" src="images/hand.jpg" alt="Task"/>
From any state where <em>all</em> philosophers are hungry, find the minimum and maximum expected time for any philosopher to eat and,
for each philosopher, from any state where he/she is hungry, the minimum and maximum expected time for that philosopher to
eat. <b>[*]</b>
</p>


<!-- ============================================================================ -->
<div class="prism-rule"></div>

<h3>Practical Report</h3>

<p>
To get this practical signed off,
you should provide the demonstrator with a brief practical report
comprising the starred items from the text above, i.e.:
<ol>
<li> from part 2: the PRISM code for the model for five philosophers;
<li> from part 3: the minimum and maximum expected time for a philosopher to eat and a description 
of an adversary which achieves the minimum;
<li> from part 4: the PRISM code for the courteous model for three philosophers;
<li> from part 5: the minimum and maximum expected time for any philosopher to eat and each philosopher to eat.
</ol>

</p>


<!-- ============================================================================ -->
<div class="prism-rule"></div>

<p>
[ <a href="index.php">Back to index</a> ]
</p>

<!-------------------------------------------------------------------------------->

<?php require '../../includes/footer.php'; ?>
