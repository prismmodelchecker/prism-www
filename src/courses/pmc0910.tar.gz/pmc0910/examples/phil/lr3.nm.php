<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>
lr3.nm
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- Style sheet "prism.css" can be found in the "etc" directory of the PRISM distribution -->
<link type="text/css" rel="stylesheet" href="prism.css">
</head>
<body text="#000000" bgcolor="#ffffff">
<pre>
<span class="prismcomment">// randomized dining philosophers [LR81]</span>
<span class="prismcomment">// three philosophers</span>

<span class="prismkeyword">mdp</span>

<span class="prismcomment">// formulae </span>
<span class="prismcomment">// left fork free (left neighbour is philosopher 2)</span>
<span class="prismkeyword">formula</span> <span class="prismident">lfree</span> = (<span class="prismident">p2</span>&gt;=<span class="prismnum">0</span> &amp; <span class="prismident">p2</span>&lt;=<span class="prismnum">4</span>) | <span class="prismident">p2</span>=<span class="prismnum">6</span> | <span class="prismident">p2</span>=<span class="prismnum">10</span>;
<span class="prismcomment">// right fork free (left neighbour is philosopher 3)</span>
<span class="prismkeyword">formula</span> <span class="prismident">rfree</span> = (<span class="prismident">p3</span>&gt;=<span class="prismnum">0</span> &amp; <span class="prismident">p3</span>&lt;=<span class="prismnum">3</span>) | <span class="prismident">p3</span>=<span class="prismnum">5</span> | <span class="prismident">p3</span>=<span class="prismnum">7</span> | <span class="prismident">p3</span>=<span class="prismnum">11</span>;

<span class="prismkeyword">module</span> <span class="prismident">phil1</span>

	<span class="prismident">p1</span>: [<span class="prismnum">0</span>..<span class="prismnum">11</span>];

	[] <span class="prismident">p1</span>=<span class="prismnum">0</span> -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">1</span>); <span class="prismcomment">// trying</span>
	[] <span class="prismident">p1</span>=<span class="prismnum">1</span> -&gt; <span class="prismnum">0.5</span> : (<span class="prismident">p1'</span>=<span class="prismnum">2</span>) + <span class="prismnum">0.5</span> : (<span class="prismident">p1'</span>=<span class="prismnum">3</span>); <span class="prismcomment">// draw randomly</span>
	[] <span class="prismident">p1</span>=<span class="prismnum">2</span> &amp;  <span class="prismident">lfree</span> -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">4</span>); <span class="prismcomment">// pick up left</span>
	[] <span class="prismident">p1</span>=<span class="prismnum">3</span> &amp;  <span class="prismident">rfree</span> -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">5</span>); <span class="prismcomment">// pick up right</span>
	[] <span class="prismident">p1</span>=<span class="prismnum">4</span> &amp;  <span class="prismident">rfree</span> -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">8</span>); <span class="prismcomment">// pick up right (got left)</span>
	[] <span class="prismident">p1</span>=<span class="prismnum">4</span> &amp; !<span class="prismident">rfree</span> -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">6</span>); <span class="prismcomment">// right not free (got left)</span>
	[] <span class="prismident">p1</span>=<span class="prismnum">5</span> &amp;  <span class="prismident">lfree</span> -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">8</span>); <span class="prismcomment">// pick up left (got right)</span>
	[] <span class="prismident">p1</span>=<span class="prismnum">5</span> &amp; !<span class="prismident">lfree</span> -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">7</span>); <span class="prismcomment">// left not free (got right)</span>
	[] <span class="prismident">p1</span>=<span class="prismnum">6</span>  -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">1</span>); <span class="prismcomment">// put down left</span>
	[] <span class="prismident">p1</span>=<span class="prismnum">7</span>  -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">1</span>); <span class="prismcomment">// put down right</span>
	[] <span class="prismident">p1</span>=<span class="prismnum">8</span>  -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">9</span>); <span class="prismcomment">// move to eating (got forks)</span>
	[] <span class="prismident">p1</span>=<span class="prismnum">9</span>  -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">10</span>); <span class="prismcomment">// finished eating and put down left </span>
	[] <span class="prismident">p1</span>=<span class="prismnum">9</span>  -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">11</span>); <span class="prismcomment">// finished eating and put down right</span>
	[] <span class="prismident">p1</span>=<span class="prismnum">10</span> -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">0</span>); <span class="prismcomment">// put down right and return to think</span>
	[] <span class="prismident">p1</span>=<span class="prismnum">11</span> -&gt; (<span class="prismident">p1'</span>=<span class="prismnum">0</span>); <span class="prismcomment">// put down left and return to think</span>

<span class="prismkeyword">endmodule</span>

<span class="prismcomment">// construct further modules through renaming</span>
<span class="prismkeyword">module</span> <span class="prismident">phil2</span> = <span class="prismident">phil1</span> [ <span class="prismident">p1</span>=<span class="prismident">p2</span>, <span class="prismident">p2</span>=<span class="prismident">p3</span>, <span class="prismident">p3</span>=<span class="prismident">p1</span> ] <span class="prismkeyword">endmodule</span>
<span class="prismkeyword">module</span> <span class="prismident">phil3</span> = <span class="prismident">phil1</span> [ <span class="prismident">p1</span>=<span class="prismident">p3</span>, <span class="prismident">p2</span>=<span class="prismident">p1</span>, <span class="prismident">p3</span>=<span class="prismident">p2</span> ] <span class="prismkeyword">endmodule</span>

<span class="prismcomment">// labels</span>

<span class="prismcomment">// a philosopher is hungry</span>
<span class="prismkeyword">label</span> "<span class="prismident">hungry</span>" = ((<span class="prismident">p1</span>&gt;<span class="prismnum">0</span>)&amp;(<span class="prismident">p1</span>&lt;<span class="prismnum">8</span>))|((<span class="prismident">p2</span>&gt;<span class="prismnum">0</span>)&amp;(<span class="prismident">p2</span>&lt;<span class="prismnum">8</span>))|((<span class="prismident">p3</span>&gt;<span class="prismnum">0</span>)&amp;(<span class="prismident">p3</span>&lt;<span class="prismnum">8</span>)); 
 <span class="prismcomment">// a philosopher is eating</span>
<span class="prismkeyword">label</span> "<span class="prismident">eat</span>" = ((<span class="prismident">p1</span>&gt;=<span class="prismnum">8</span>)&amp;(<span class="prismident">p1</span>&lt;=<span class="prismnum">9</span>))|((<span class="prismident">p2</span>&gt;=<span class="prismnum">8</span>)&amp;(<span class="prismident">p2</span>&lt;=<span class="prismnum">9</span>))|((<span class="prismident">p3</span>&gt;=<span class="prismnum">8</span>)&amp;(<span class="prismident">p3</span>&lt;=<span class="prismnum">9</span>));
<span class="prismcomment">// philosopher 1 is hungry</span>
<span class="prismkeyword">label</span> "<span class="prismident">hungry1</span>" = (<span class="prismident">p1</span>&gt;<span class="prismnum">0</span>)&amp;(<span class="prismident">p1</span>&lt;<span class="prismnum">8</span>);
<span class="prismcomment">// philosopher 2 is hungry</span>
<span class="prismkeyword">label</span> "<span class="prismident">hungry2</span>" = (<span class="prismident">p2</span>&gt;<span class="prismnum">0</span>)&amp;(<span class="prismident">p2</span>&lt;<span class="prismnum">8</span>);
<span class="prismcomment">// philosopher 3 is hungry</span>
<span class="prismkeyword">label</span> "<span class="prismident">hungry3</span>" = (<span class="prismident">p3</span>&gt;<span class="prismnum">0</span>)&amp;(<span class="prismident">p3</span>&lt;<span class="prismnum">8</span>);
 <span class="prismcomment">// philosopher 1 is eating</span>
<span class="prismkeyword">label</span> "<span class="prismident">eat1</span>" = (<span class="prismident">p1</span>&gt;=<span class="prismnum">8</span>)&amp;(<span class="prismident">p1</span>&lt;=<span class="prismnum">9</span>);
 <span class="prismcomment">// philosopher 2 is eating</span>
<span class="prismkeyword">label</span> "<span class="prismident">eat2</span>" = (<span class="prismident">p2</span>&gt;=<span class="prismnum">8</span>)&amp;(<span class="prismident">p2</span>&lt;=<span class="prismnum">9</span>);
 <span class="prismcomment">// philosopher 3 is eating</span>
<span class="prismkeyword">label</span> "<span class="prismident">eat3</span>" = (<span class="prismident">p3</span>&gt;=<span class="prismnum">8</span>)&amp;(<span class="prismident">p3</span>&lt;=<span class="prismnum">9</span>);
</pre>
</body>
</html>
