<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>
new_rewards.sm
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- Style sheet "prism.css" can be found in the "etc" directory of the PRISM distribution -->
<link type="text/css" rel="stylesheet" href="prism.css">
</head>
<body text="#000000" bgcolor="#ffffff">
<pre>
<span class="prismkeyword">rewards</span> "<span class="prismident">lost</span>"
	[<span class="prismident">request</span>] <span class="prismident">q</span>=<span class="prismident">q_max</span> : <span class="prismnum">1</span>;
<span class="prismkeyword">endrewards</span>

<span class="prismkeyword">R</span>{"<span class="prismident">lost</span>"}=?[<span class="prismkeyword">C</span>&lt;=<span class="prismident">t</span>]

<span class="prismkeyword">rewards</span> "<span class="prismident">power</span>"
	<span class="prismident">sp</span>=<span class="prismnum">0</span> : <span class="prismnum">0.13</span>;
	<span class="prismident">sp</span>=<span class="prismnum">1</span> : <span class="prismnum">0.95</span>;
	<span class="prismident">sp</span>=<span class="prismnum">2</span> : <span class="prismnum">2.15</span>;
	[<span class="prismident">sleep2idle</span>] <span class="prismkeyword">true</span> : <span class="prismnum">7</span>;
	[<span class="prismident">idle2sleep</span>] <span class="prismkeyword">true</span> : <span class="prismnum">0.067</span>;
<span class="prismkeyword">endrewards</span>

<span class="prismkeyword">R</span>{"<span class="prismident">power</span>"}=?[<span class="prismkeyword">C</span>&lt;=<span class="prismident">t</span>]

</pre>
</body>
</html>
