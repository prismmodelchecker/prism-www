<span class="prismkeyword">rewards</span> "<span class="prismident">lost</span>"
	[<span class="prismident">request</span>] <span class="prismident">q</span>=<span class="prismident">q_max</span> : <span class="prismnum">1</span>;
<span class="prismkeyword">endrewards</span>

<span class="prismkeyword">R</span>{"<span class="prismident">lost</span>"}=?[<span class="prismkeyword">C</span>&lt;=<span class="prismident">t</span>]

<span class="prismkeyword">rewards</span> "<span class="prismident">power</span>"
	<span class="prismident">sp</span>=<span class="prismnum">0</span> : <span class="prismnum">0.13</span>;
	<span class="prismident">sp</span>=<span class="prismnum">1</span> : <span class="prismnum">0.95</span>;
	<span class="prismident">sp</span>=<span class="prismnum">2</span> : <span class="prismnum">2.15</span>;
	[<span class="prismident">sleep2idle</span>] <span class="prismkeyword">true</span> : <span class="prismnum">7</span>;
	[<span class="prismident">idle2sleep</span>] <span class="prismkeyword">true</span> : <span class="prismnum">0.067</span>;
<span class="prismkeyword">endrewards</span>

<span class="prismkeyword">R</span>{"<span class="prismident">power</span>"}=?[<span class="prismkeyword">C</span>&lt;=<span class="prismident">t</span>]

