<span class="prismcomment">// Probability of ordering the SP to sleep when queue empty</span>
<span class="prismkeyword">const</span> <span class="prismkeyword">double</span> <span class="prismident">p_sleep</span>;

<span class="prismkeyword">module</span> <span class="prismident">PM</span>
	
	<span class="prismcomment">// i2s: true when idle2sleep command should be issued</span>
	<span class="prismident">i2s</span> : <span class="prismkeyword">bool</span> <span class="prismkeyword">init</span> <span class="prismkeyword">false</span>;
	<span class="prismcomment">// s2i: true when sleep2idle command should be issued</span>
	<span class="prismident">s2i</span> : <span class="prismkeyword">bool</span> <span class="prismkeyword">init</span> <span class="prismkeyword">false</span>;
	
	<span class="prismcomment">// idle to sleep command triggered by request arrivals/services</span>
	<span class="prismcomment">//  decide to perform command when queue becomes empty with probability p_sleep</span>
	[<span class="prismident">serve_last</span>] <span class="prismkeyword">true</span> -&gt; <span class="prismident">p_sleep</span> : (<span class="prismident">i2s'</span>=<span class="prismkeyword">true</span>) + <span class="prismnum">1</span>-<span class="prismident">p_sleep</span> : (<span class="prismident">i2s'</span>=<span class="prismkeyword">false</span>);
	<span class="prismcomment">// cancel idle to sleep command if a reqest arrives</span>
	[<span class="prismident">request</span>] <span class="prismkeyword">true</span> -&gt; (<span class="prismident">i2s'</span>=<span class="prismkeyword">false</span>);
	
	<span class="prismcomment">// Send idle2sleep command to SP</span>
	[<span class="prismident">idle2sleep</span>] <span class="prismident">i2s</span> -&gt; (<span class="prismident">i2s'</span>=<span class="prismkeyword">false</span>);
	 
	<span class="prismcomment">// sleep to idle command triggered by reqest arrives</span>
	<span class="prismcomment">// when request arrives trigger command with a certain probability and probability dependent on the queue size</span>
	<span class="prismcomment">// (should really be based on q+1 not q as this is the queue size when the probabilistic choice is made)</span>
	[<span class="prismident">request</span>] <span class="prismkeyword">true</span> -&gt; <span class="prismkeyword">min</span>(<span class="prismident">q</span>+<span class="prismnum">1</span>,<span class="prismident">q_max</span>)/<span class="prismident">q_max</span> : (<span class="prismident">s2i'</span>=<span class="prismkeyword">true</span>) + <span class="prismnum">1</span>-<span class="prismkeyword">min</span>(<span class="prismident">q</span>+<span class="prismnum">1</span>,<span class="prismident">q_max</span>)/<span class="prismident">q_max</span> : (<span class="prismident">s2i'</span>=<span class="prismkeyword">false</span>);
	<span class="prismcomment">// Send sleep2idle command to SP</span>
	[<span class="prismident">sleep2idle</span>] <span class="prismident">s2i</span> -&gt; (<span class="prismident">s2i'</span>=<span class="prismkeyword">false</span>);
	
<span class="prismkeyword">endmodule</span>
